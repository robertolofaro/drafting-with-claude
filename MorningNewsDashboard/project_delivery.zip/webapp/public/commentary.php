<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if ($id) {
    // Single commentary view — teaser is free, full body is token-gated.
    $c = find_commentary($id);
    if (!$c || $c['status'] !== 'published') {
        http_response_code(404);
        $pageTitle = 'Commentary not found';
        require __DIR__ . '/../includes/layout_top.php';
        echo '<div class="card"><p>No such commentary.</p></div>';
        require __DIR__ . '/../includes/layout_bottom.php';
        exit;
    }

    $fullAccess = has_full_access();
    $pageTitle = $c['headline'];
    require __DIR__ . '/../includes/layout_top.php';
    ?>
    <div class="card">
        <h2><?= h($c['headline']) ?></h2>
        <p class="meta muted">
            <?= h(fmt_date($c['brief_date'])) ?>
            <?php if ($c['theme_code']): ?><span class="tag"><?= h($c['theme_code']) ?></span><?php endif; ?>
        </p>
        <p><?= h($c['teaser']) ?></p>

        <?php if ($fullAccess): ?>
            <div style="margin-top:14px;"><?= render_commentary_markdown($c['body_markdown']) ?></div>

            <?php $items = commentary_items((int)$c['id']); if ($items): ?>
                <h3 style="font-size:0.95rem;">Referenced items</h3>
                <ul>
                    <?php foreach ($items as $it): ?>
                        <li><a href="<?= h($it['cached_permalink']) ?>"><?= h($it['cached_title']) ?></a> <span class="muted">(<?= h(fmt_date($it['cached_brief_date'])) ?>)</span></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        <?php else: ?>
            <div class="locked-note">The full analysis, with linked sources, unlocks with a token.</div>
            <p><a href="unlock.php?return=<?= urlencode('commentary.php?id=' . $id) ?>"><button>Unlock full access</button></a></p>
        <?php endif; ?>

        <p style="margin-top:14px;"><a href="commentary.php">← All commentary</a></p>
    </div>
    <?php
    require __DIR__ . '/../includes/layout_bottom.php';
    exit;
}

// List view
$theme = trim((string)($_GET['theme'] ?? '')) ?: null;
$list = list_commentaries($theme);
$themeOptions = app_themes();

$pageTitle = 'Commentary';
require __DIR__ . '/../includes/layout_top.php';
?>

<div class="card">
    <h2>Editorial commentary</h2>
    <form class="inline" method="get">
        <select name="theme" onchange="this.form.submit()">
            <option value="">All themes</option>
            <?php foreach ($themeOptions as $t): ?>
                <option value="<?= h($t['code']) ?>" <?= $theme === $t['code'] ? 'selected' : '' ?>><?= h($t['label']) ?></option>
            <?php endforeach; ?>
        </select>
    </form>
</div>

<div class="card">
    <?php foreach ($list as $c): ?>
        <div class="item-row">
            <div class="title"><a href="commentary.php?id=<?= (int)$c['id'] ?>"><?= h($c['headline']) ?></a></div>
            <div class="meta"><?= h(fmt_date($c['brief_date'])) ?> <?php if ($c['theme_code']): ?><span class="tag"><?= h($c['theme_code']) ?></span><?php endif; ?></div>
            <div class="snippet"><?= h($c['teaser']) ?></div>
        </div>
    <?php endforeach; ?>
    <?php if (!$list): ?><p class="muted">No commentary published yet.</p><?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_bottom.php'; ?>

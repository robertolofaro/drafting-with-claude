<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

$hasQuery = isset($_GET['q']) || isset($_GET['date']) || isset($_GET['domain']) || isset($_GET['theme']);

if ($hasQuery && !has_full_access()) {
    require_full_access('search.php?' . http_build_query($_GET));
}

$keyword = trim((string)($_GET['q'] ?? '')) ?: null;
$date = preg_match('/^\d{8}$/', (string)($_GET['date'] ?? '')) ? $_GET['date'] : null;
$domain = valid_domain($_GET['domain'] ?? null);
$theme = trim((string)($_GET['theme'] ?? '')) ?: null;

$itemResults = [];
$commentaryResults = [];
if ($hasQuery && has_full_access()) {
    $itemResults = search_source_items($date, $domain, $theme, $keyword, 200);
    $commentaryResults = search_commentaries($date, $theme, $keyword);
}

$themeOptions = source_themes();
$dateOptions = source_db()->query('SELECT DISTINCT brief_date FROM files ORDER BY brief_date DESC LIMIT 60')->fetchAll();

$pageTitle = 'Search';
require __DIR__ . '/../includes/layout_top.php';
?>

<div class="card">
    <h2>Search source items &amp; commentary</h2>
    <?php if (!has_full_access()): ?>
        <p class="muted">Full cross-database search (by keyword, domain, theme or date) unlocks with a token.</p>
        <a href="unlock.php?return=search.php"><button>Unlock full access</button></a>
    <?php else: ?>
        <form class="inline" method="get">
            <input type="text" name="q" placeholder="Keyword…" value="<?= h($keyword ?? '') ?>">
            <select name="domain">
                <option value="">All domains</option>
                <?php foreach (DOMAINS as $code => $meta): ?>
                    <option value="<?= h($code) ?>" <?= $domain === $code ? 'selected' : '' ?>><?= h($meta['label']) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="theme">
                <option value="">All themes</option>
                <?php foreach ($themeOptions as $t): ?>
                    <option value="<?= h($t) ?>" <?= $theme === $t ? 'selected' : '' ?>><?= h($t) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="date">
                <option value="">All dates</option>
                <?php foreach ($dateOptions as $d): ?>
                    <option value="<?= h($d['brief_date']) ?>" <?= $date === $d['brief_date'] ? 'selected' : '' ?>><?= h(fmt_date($d['brief_date'])) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Search</button>
        </form>
    <?php endif; ?>
</div>

<?php if (has_full_access() && $hasQuery): ?>

    <div class="card">
        <h2>Source items <small><?= count($itemResults) ?> result(s)</small></h2>
        <table class="search-results">
            <tr><th>Date</th><th>Domain</th><th>Title</th><th>Trend</th></tr>
            <?php foreach ($itemResults as $r): ?>
                <tr>
                    <td><?= h(fmt_date($r['brief_date'])) ?></td>
                    <td><?= h(domain_label($r['category'])) ?></td>
                    <td><a href="<?= h(item_permalink($r['category'], (int)$r['file_id'], (int)$r['item_number'])) ?>"><?= h($r['title']) ?></a></td>
                    <td><?= h($r['trend_raw']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$itemResults): ?><tr><td colspan="4" class="muted">No matching items.</td></tr><?php endif; ?>
        </table>
    </div>

    <div class="card">
        <h2>Commentary <small><?= count($commentaryResults) ?> result(s)</small></h2>
        <?php foreach ($commentaryResults as $c): ?>
            <div class="item-row">
                <div class="title"><a href="commentary.php?id=<?= (int)$c['id'] ?>"><?= h($c['headline']) ?></a></div>
                <div class="meta"><?= h(fmt_date($c['brief_date'])) ?> <?php if ($c['theme_code']): ?><span class="tag"><?= h($c['theme_code']) ?></span><?php endif; ?></div>
            </div>
        <?php endforeach; ?>
        <?php if (!$commentaryResults): ?><p class="muted">No matching commentary.</p><?php endif; ?>
    </div>

<?php endif; ?>

<?php require __DIR__ . '/../includes/layout_bottom.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

$requestedDate = isset($_GET['date']) && preg_match('/^\d{8}$/', (string)$_GET['date']) ? $_GET['date'] : null;
$briefDate = $requestedDate ?: latest_brief_date();

$file = $briefDate ? file_for_date($briefDate) : null;
$overview = $file ? brief_overview((int)$file['id']) : ['title' => null, 'digest' => [], 'signals' => null];

$fullAccess = has_full_access();
$itemLimit = $fullAccess ? 0 : RESTRICTED_ITEMS_PER_DOMAIN; // 0 = no limit

$pageTitle = 'Overview — ' . ($briefDate ? fmt_date($briefDate) : 'Morning Brief Dashboard');
require __DIR__ . '/../includes/layout_top.php';
?>

<?php if (!$fullAccess): ?>
<div class="cta">
    <h2>You're viewing the restricted dashboard</h2>
    <p>Headlines and trend direction are free. Full item summaries, significance notes, original sources,
       editorial commentary, and cross-database search unlock with a token.</p>
    <a href="unlock.php"><button>Unlock full access</button></a>
</div>
<?php endif; ?>

<div class="card">
    <h2>
        <?= $overview['title'] ? h($overview['title']['title_line']) : 'Morning Brief' ?>
        <small><?= $overview['title'] ? h($overview['title']['date_time_line']) : '' ?></small>
    </h2>
    <?php if ($overview['title']): ?>
        <p class="muted"><?= h($overview['title']['summary_line']) ?></p>
    <?php endif; ?>

    <?php if ($overview['signals']): ?>
        <div class="locked-note" style="border-style:solid;">
            <strong>Signal board</strong><br>
            <?= nl2br(h($overview['signals']['text'])) ?>
        </div>
    <?php endif; ?>

    <?php if ($overview['digest']): ?>
        <table class="search-results" style="margin-top:12px;">
            <tr><th>Category</th><th>Stories</th><th>Alert</th></tr>
            <?php foreach ($overview['digest'] as $d): ?>
                <tr>
                    <td><?= h($d['category_raw']) ?></td>
                    <td><?= h((string)$d['stories_count']) ?></td>
                    <td><?= h($d['alert_raw']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <?php
    $dates = source_db()->query('SELECT DISTINCT brief_date FROM files ORDER BY brief_date DESC LIMIT 14')->fetchAll();
    ?>
    <form class="inline" method="get" style="margin-top:12px;">
        <label class="muted" for="date">Jump to date:</label>
        <select name="date" id="date" onchange="this.form.submit()">
            <?php foreach ($dates as $d): ?>
                <option value="<?= h($d['brief_date']) ?>" <?= $d['brief_date'] === $briefDate ? 'selected' : '' ?>>
                    <?= h(fmt_date($d['brief_date'])) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>
</div>

<?php if ($file): foreach (DOMAINS as $code => $meta): ?>
    <?php $items = items_for_domain($code, (int)$file['id'], $itemLimit); ?>
    <div class="card">
        <h2><?= h($meta['label']) ?> <small><?= count($items) ?> item(s)<?= $fullAccess ? '' : ' shown' ?></small></h2>
        <?php foreach ($items as $it): ?>
            <div class="item-row">
                <div class="title">
                    <?php if ($fullAccess): ?>
                        <a href="<?= h(item_permalink($code, (int)$file['id'], (int)$it['item_number'])) ?>"><?= h($it['title']) ?></a>
                    <?php else: ?>
                        <?= h($it['title']) ?>
                    <?php endif; ?>
                </div>
                <div class="meta">
                    <?= h($it['alert_raw']) ?> <?= h($it['trend_raw']) ?>
                    <?php if ($it['multi_source']): ?><span class="tag">multi-source</span><?php endif; ?>
                </div>
                <?php if ($fullAccess): ?>
                    <div class="snippet"><?= h($it['summary']) ?></div>
                    <?php if ($it['significance']): ?>
                        <div class="snippet muted"><em><?= h($it['significance']) ?></em></div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="snippet"><?= h(truncate($it['summary'], RESTRICTED_SUMMARY_CHARS)) ?></div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!$fullAccess): ?>
            <div class="locked-note">Full summaries, significance notes and original sources for every item unlock with a token.</div>
        <?php endif; ?>
    </div>
<?php endforeach; endif; ?>

<div class="card">
    <h2>Latest commentary <small><a href="commentary.php">view all</a></small></h2>
    <?php foreach (array_slice(list_commentaries(), 0, 3) as $c): ?>
        <div class="item-row">
            <div class="title"><a href="commentary.php?id=<?= (int)$c['id'] ?>"><?= h($c['headline']) ?></a></div>
            <div class="meta"><?= h(fmt_date($c['brief_date'])) ?> <?php if ($c['theme_code']): ?><span class="tag"><?= h($c['theme_code']) ?></span><?php endif; ?></div>
            <div class="snippet"><?= h($c['teaser']) ?></div>
        </div>
    <?php endforeach; ?>
    <?php if (!list_commentaries()): ?><p class="muted">No commentary published yet.</p><?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_bottom.php'; ?>

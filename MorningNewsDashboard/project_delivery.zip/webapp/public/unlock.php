<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $result = ['ok' => false, 'message' => 'Form expired, please try again.'];
    } else {
        $result = redeem_token((string)($_POST['token'] ?? ''));
    }
}

$returnTo = $_GET['return'] ?? ($_POST['return'] ?? 'index.php');
$returnTo = filter_var($returnTo, FILTER_DEFAULT) ?: 'index.php';
// Only allow redirecting back into this app's own pages.
if (!preg_match('#^[a-zA-Z0-9_\-]+\.php(\?.*)?$#', $returnTo)) {
    $returnTo = 'index.php';
}

// Smooth hand-off: a successful POST redirects straight to where the reader was headed.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $result && $result['ok']) {
    header('Location: ' . $returnTo);
    exit;
}

$pageTitle = 'Unlock full access';
require __DIR__ . '/../includes/layout_top.php';
?>

<div class="card" style="max-width:480px;">
    <h2>Unlock full access</h2>
    <p class="muted">Enter a token from one of your packages to unlock full item summaries, sources,
       commentary and search for <?= (int)ACCESS_WINDOW_HOURS ?> hours. One credit is spent each time a
       new access window is opened.</p>

    <?php if ($result): ?>
        <p class="<?= $result['ok'] ? 'flash-ok' : 'flash-error' ?>"><?= h($result['message']) ?></p>
    <?php endif; ?>

    <?php if (has_full_access()): ?>
        <p><a href="<?= h($returnTo) ?>"><button>Continue to the full dashboard →</button></a></p>
    <?php else: ?>
        <form method="post">
            <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
            <input type="hidden" name="return" value="<?= h($returnTo) ?>">
            <p>
                <input type="text" name="token" placeholder="Paste your token" style="width:100%;" autofocus required>
            </p>
            <button type="submit">Unlock</button>
        </form>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_bottom.php'; ?>

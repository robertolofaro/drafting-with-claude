<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

$fileId = isset($_GET['file_id']) ? (int)$_GET['file_id'] : 0;
$category = valid_domain($_GET['category'] ?? null);
$itemNumber = isset($_GET['n']) ? (int)$_GET['n'] : 0;

if (!$fileId || !$category || !$itemNumber) {
    http_response_code(400);
    $pageTitle = 'Item not found';
    require __DIR__ . '/../includes/layout_top.php';
    echo '<div class="card"><p>This item link looks malformed.</p></div>';
    require __DIR__ . '/../includes/layout_bottom.php';
    exit;
}

if (!has_full_access()) {
    require_full_access('item.php?' . http_build_query(['file_id' => $fileId, 'category' => $category, 'n' => $itemNumber]));
}

$item = find_item($category, $fileId, $itemNumber);
if (!$item) {
    http_response_code(404);
    $pageTitle = 'Item not found';
    require __DIR__ . '/../includes/layout_top.php';
    echo '<div class="card"><p>No such item — it may have been removed in a later source DB update.</p></div>';
    require __DIR__ . '/../includes/layout_bottom.php';
    exit;
}

$sources = item_sources_for($category, $fileId, $itemNumber);
$themes = item_themes_for($category, $fileId, $itemNumber);
$file = source_db()->prepare('SELECT * FROM files WHERE id = ?');
$file->execute([$fileId]);
$file = $file->fetch();

$pageTitle = $item['title'];
require __DIR__ . '/../includes/layout_top.php';
?>

<div class="card">
    <h2><?= h($item['title']) ?></h2>
    <p class="meta muted">
        <span class="tag"><?= h(domain_label($category)) ?></span>
        <?= h(fmt_date($file['brief_date'] ?? '')) ?>
        · <?= h($item['alert_raw']) ?> <?= h($item['trend_raw']) ?>
        <?php foreach ($themes as $t): ?><span class="tag"><?= h($t) ?></span><?php endforeach; ?>
    </p>

    <p><?= nl2br(h($item['summary'])) ?></p>

    <?php if ($item['significance']): ?>
        <p class="muted"><strong>Significance:</strong> <?= nl2br(h($item['significance'])) ?></p>
    <?php endif; ?>

    <?php if ($sources): ?>
        <h3 style="font-size:0.95rem;">Original sources</h3>
        <ul>
            <?php foreach ($sources as $s): ?>
                <li><a href="<?= h($s['url']) ?>" target="_blank" rel="noopener noreferrer"><?= h($s['source_title'] ?: $s['url']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <p><a href="index.php?date=<?= h($file['brief_date'] ?? '') ?>">← Back to <?= h(fmt_date($file['brief_date'] ?? '')) ?> overview</a></p>
</div>

<?php require __DIR__ . '/../includes/layout_bottom.php'; ?>

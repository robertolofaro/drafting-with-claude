<?php
/**
 * config.php — single place to point the dashboard at its two databases and
 * tune the token/access model. Nothing else in webapp/ should hardcode a
 * path or a business rule that belongs here.
 *
 * Swapping the SOURCE database from SQLite to MySQL/Postgres later only
 * means changing SOURCE_DB_DSN (+ credentials) below — includes/db.php uses
 * plain PDO and the SQL in this project avoids SQLite-only syntax, so no
 * other file should need to change. The APP database (commentary + tokens)
 * can be migrated the same way, independently.
 */

declare(strict_types=1);

// --- Source database (read-only; updated weekly by your ingestion pipeline) ---
// SQLite (default, matches the file you provided):
define('SOURCE_DB_DSN', 'sqlite:' . __DIR__ . '/../data/morning_news.sqlite3');
define('SOURCE_DB_USER', null);
define('SOURCE_DB_PASS', null);
// MySQL example, if you move the source DB there later:
//   define('SOURCE_DB_DSN', 'mysql:host=localhost;dbname=morning_news;charset=utf8mb4');
//   define('SOURCE_DB_USER', 'morning_news_ro');
//   define('SOURCE_DB_PASS', 'change-me');

// --- App database (read-write; commentary + token system) ---
define('APP_DB_DSN', 'sqlite:' . __DIR__ . '/../data/app.sqlite3');
define('APP_DB_USER', null);
define('APP_DB_PASS', null);

// --- Access / token model ---
// How long a redeemed token's "full access window" lasts before another
// credit must be spent to re-open it. 1 credit is spent per NEW window,
// not per page view — see includes/auth.php.
define('ACCESS_WINDOW_HOURS', 24);

// How many items to show per domain on the restricted (free) dashboard,
// and how much of each summary to reveal there (characters).
define('RESTRICTED_ITEMS_PER_DOMAIN', 5);
define('RESTRICTED_SUMMARY_CHARS', 160);

// Results per page for the full-access search.
define('SEARCH_PAGE_SIZE', 25);

// Domain (agent_*) catalogue — keep in sync with commentary_app/commentary_app.py
// DOMAINS and commentary_db/schema.sql's `domains` table.
define('DOMAINS', [
    'CONFLICT'   => ['label' => 'Conflict',    'table' => 'agent_conflict'],
    'BUSINESS'   => ['label' => 'Business',    'table' => 'agent_business'],
    'EU_AFFAIRS' => ['label' => 'EU Affairs',  'table' => 'agent_eu_affairs'],
    'TECHNOLOGY' => ['label' => 'Technology',  'table' => 'agent_technology'],
    'TRENDS'     => ['label' => 'Trends',      'table' => 'agent_trends'],
]);

// Session cookie lifetime: by default PHP ends the session when the browser
// closes, which is shorter than a 24h access window. Extend it so a reader
// who closes their browser mid-window doesn't have to re-enter a token.
ini_set('session.cookie_lifetime', (string)(ACCESS_WINDOW_HOURS * 3600));
ini_set('session.gc_maxlifetime', (string)(ACCESS_WINDOW_HOURS * 3600));

<?php
/**
 * issue_token.php — CLI tool to create a token package and mint tokens.
 * Run from a shell, NOT reachable over the web (keep this file outside your
 * webroot, or at least block admin/ in your webserver config — see
 * docs/ARCHITECTURE.md).
 *
 * Usage:
 *   php issue_token.php create-package "10-pack" 10 2900 EUR
 *       -> creates a package named "10-pack" worth 10 credits, 29.00 EUR
 *
 *   php issue_token.php mint <package_id> [issued_to_note]
 *       -> mints ONE new token against that package and prints the
 *          plaintext token ONCE. It is not recoverable afterwards — only
 *          its SHA-256 hash is stored. Give/sell this string to the buyer.
 *
 *   php issue_token.php list-packages
 *   php issue_token.php list-tokens [package_id]
 *   php issue_token.php revoke <token_id>
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('This script is for command-line use only.');
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';

function usage(): never
{
    fwrite(STDERR, "See the header comment in this file for usage.\n");
    exit(1);
}

$args = $argv;
array_shift($args); // script name
$cmd = array_shift($args);

$db = app_db();

switch ($cmd) {
    case 'create-package': {
        [$name, $credits, $priceCents, $currency] = $args + [null, null, null, 'EUR'];
        if (!$name || !$credits) {
            usage();
        }
        $stmt = $db->prepare('INSERT INTO token_packages (name, credits, price_cents, currency) VALUES (?,?,?,?)');
        $stmt->execute([$name, (int)$credits, $priceCents !== null ? (int)$priceCents : null, $currency]);
        echo "Created package #{$db->lastInsertId()}: {$name} ({$credits} credits)\n";
        break;
    }

    case 'mint': {
        [$packageId, $issuedTo] = $args + [null, null];
        if (!$packageId) {
            usage();
        }
        $pkg = $db->prepare('SELECT * FROM token_packages WHERE id = ?');
        $pkg->execute([(int)$packageId]);
        $pkg = $pkg->fetch();
        if (!$pkg) {
            fwrite(STDERR, "No such package.\n");
            exit(1);
        }

        $plainToken = bin2hex(random_bytes(20)); // 40 hex chars
        $hash = hash('sha256', $plainToken);

        $stmt = $db->prepare(
            'INSERT INTO tokens (token_hash, package_id, credits_total, credits_remaining, issued_to)
             VALUES (?,?,?,?,?)'
        );
        $stmt->execute([$hash, $pkg['id'], $pkg['credits'], $pkg['credits'], $issuedTo]);

        echo "Token minted (id #{$db->lastInsertId()}), package '{$pkg['name']}', {$pkg['credits']} credits.\n";
        echo "Give this token to the buyer now — it will not be shown again:\n\n";
        echo "  {$plainToken}\n\n";
        break;
    }

    case 'list-packages': {
        foreach ($db->query('SELECT * FROM token_packages ORDER BY id') as $p) {
            printf("#%d  %-20s credits=%-5d price=%s %s\n", $p['id'], $p['name'], $p['credits'],
                $p['price_cents'] !== null ? number_format($p['price_cents'] / 100, 2) : '-', $p['currency']);
        }
        break;
    }

    case 'list-tokens': {
        $pkgId = $args[0] ?? null;
        $sql = 'SELECT t.*, p.name AS package_name FROM tokens t LEFT JOIN token_packages p ON p.id = t.package_id';
        $params = [];
        if ($pkgId) {
            $sql .= ' WHERE t.package_id = ?';
            $params[] = (int)$pkgId;
        }
        $sql .= ' ORDER BY t.id';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        foreach ($stmt as $t) {
            printf("#%d  package=%-15s remaining=%d/%d  status=%-9s issued_to=%s\n",
                $t['id'], $t['package_name'] ?? '-', $t['credits_remaining'], $t['credits_total'],
                $t['status'], $t['issued_to'] ?? '-');
        }
        break;
    }

    case 'revoke': {
        $tokenId = $args[0] ?? null;
        if (!$tokenId) {
            usage();
        }
        $db->prepare("UPDATE tokens SET status='revoked' WHERE id=?")->execute([(int)$tokenId]);
        echo "Token #{$tokenId} revoked.\n";
        break;
    }

    default:
        usage();
}

<?php
/**
 * auth.php — token redemption and the "full access window" check that every
 * page uses to decide between the restricted and full view.
 *
 * Model: a token has N credits. Submitting a valid token with at least one
 * credit remaining opens a full-access window lasting ACCESS_WINDOW_HOURS
 * and spends exactly 1 credit. Returning during that window (same PHP
 * session) costs nothing further. The window's expiry is cached in the PHP
 * session so most page loads don't need a DB round-trip to check access.
 */

declare(strict_types=1);
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** True if this browser session currently has an open, unexpired full-access window. */
function has_full_access(): bool
{
    $expires = $_SESSION['window_expires_at'] ?? null;
    if ($expires === null) {
        return false;
    }
    return strtotime($expires) > time();
}

/** Remaining seconds in the current access window, or 0. */
function access_window_seconds_left(): int
{
    if (!has_full_access()) {
        return 0;
    }
    return max(0, strtotime($_SESSION['window_expires_at']) - time());
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_check(?string $submitted): bool
{
    return is_string($submitted) && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $submitted);
}

/**
 * Attempt to redeem a plaintext token string. Returns an associative array:
 *   ['ok' => bool, 'message' => string, 'credits_remaining' => ?int]
 */
function redeem_token(string $plainToken): array
{
    $plainToken = trim($plainToken);
    if ($plainToken === '') {
        return ['ok' => false, 'message' => 'Please enter a token.', 'credits_remaining' => null];
    }

    // Already inside a valid window? Nothing to spend.
    if (has_full_access()) {
        return ['ok' => true, 'message' => 'Full access is already unlocked for this session.', 'credits_remaining' => null];
    }

    $hash = hash('sha256', $plainToken);
    $db = app_db();
    $db->beginTransaction();
    try {
        $stmt = $db->prepare(
            "SELECT * FROM tokens
             WHERE token_hash = ? AND status = 'active'
               AND (expires_at IS NULL OR expires_at > datetime('now'))
             LIMIT 1"
        );
        $stmt->execute([$hash]);
        $token = $stmt->fetch();

        if (!$token) {
            $db->rollBack();
            return ['ok' => false, 'message' => 'That token is not valid, has expired, or has been revoked.', 'credits_remaining' => null];
        }
        if ((int)$token['credits_remaining'] <= 0) {
            $db->rollBack();
            return ['ok' => false, 'message' => 'That token has no credits remaining.', 'credits_remaining' => 0];
        }

        $remaining = (int)$token['credits_remaining'] - 1;
        $newStatus = $remaining > 0 ? 'active' : 'exhausted';
        $upd = $db->prepare('UPDATE tokens SET credits_remaining = ?, status = ? WHERE id = ?');
        $upd->execute([$remaining, $newStatus, $token['id']]);

        session_regenerate_id(true); // fresh session id for this newly-opened window
        $sessionId = session_id();
        $expiresAt = date('Y-m-d H:i:s', time() + ACCESS_WINDOW_HOURS * 3600);

        $ins = $db->prepare(
            'INSERT INTO token_redemptions (token_id, session_id, expires_at, ip_address, credits_spent)
             VALUES (?, ?, ?, ?, 1)'
        );
        $ins->execute([$token['id'], $sessionId, $expiresAt, $_SERVER['REMOTE_ADDR'] ?? null]);

        $db->commit();

        $_SESSION['window_expires_at'] = $expiresAt;
        $_SESSION['token_id'] = $token['id'];

        return [
            'ok' => true,
            'message' => "Unlocked for " . ACCESS_WINDOW_HOURS . " hours. {$remaining} credit(s) remaining on this token.",
            'credits_remaining' => $remaining,
        ];
    } catch (Throwable $e) {
        $db->rollBack();
        return ['ok' => false, 'message' => 'Something went wrong redeeming the token. Please try again.', 'credits_remaining' => null];
    }
}

/** Call at the top of any page that requires full access; redirects to the unlock form otherwise. */
function require_full_access(string $returnTo = ''): void
{
    if (!has_full_access()) {
        $target = 'unlock.php' . ($returnTo ? ('?return=' . urlencode($returnTo)) : '');
        header('Location: ' . $target);
        exit;
    }
}

<?php
/** @var string $pageTitle set by the including page before require'ing this file */
declare(strict_types=1);
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($pageTitle ?? 'Dashboard') ?></title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site">
    <div class="brand"><a href="index.php" style="color:inherit">Morning Brief Dashboard</a></div>
    <nav>
        <a href="index.php">Overview</a>
        <a href="commentary.php">Commentary</a>
        <a href="search.php">Search</a>
        <?php if (has_full_access()): ?>
            <span class="access-badge full">Full access · <?= (int)ceil(access_window_seconds_left() / 3600) ?>h left</span>
        <?php else: ?>
            <a href="unlock.php">Unlock full access</a>
            <span class="access-badge restricted">Restricted view</span>
        <?php endif; ?>
    </nav>
</header>
<main>

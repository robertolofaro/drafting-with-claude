<?php
/**
 * helpers.php — small presentation helpers shared by the views.
 */

declare(strict_types=1);

function h(?string $s): string
{
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function fmt_date(?string $yyyymmdd): string
{
    if (!$yyyymmdd || strlen($yyyymmdd) !== 8) {
        return (string)$yyyymmdd;
    }
    return substr($yyyymmdd, 0, 4) . '-' . substr($yyyymmdd, 4, 2) . '-' . substr($yyyymmdd, 6, 2);
}

function truncate(?string $text, int $chars): string
{
    $text = trim($text ?? '');
    if (mb_strlen($text) <= $chars) {
        return $text;
    }
    return rtrim(mb_substr($text, 0, $chars)) . '…';
}

function item_permalink(string $domainCode, int $fileId, int $itemNumber): string
{
    return 'item.php?file_id=' . $fileId . '&category=' . urlencode($domainCode) . '&n=' . $itemNumber;
}

/**
 * Minimal, safe markdown subset for commentary bodies: the text is HTML-escaped
 * first (so nothing in it can inject markup), THEN a small set of patterns are
 * turned into real tags. This order matters — escaping after linkification
 * would mangle the hrefs. Supports:
 *   [text](relative-or-absolute-url)   -> <a>
 *   **bold**                            -> <strong>
 *   blank-line-separated paragraphs     -> <p>
 */
function render_commentary_markdown(string $text): string
{
    $escaped = h($text);

    // Links: [label](target). We escaped already, so both label and target
    // are plain text at this point — safe to re-assemble into an <a> tag.
    $escaped = preg_replace_callback(
        '/\[([^\]]+)\]\(([^)]+)\)/',
        function (array $m): string {
            $label = $m[1];
            $target = $m[2];
            // Only allow relative dashboard links or http(s) URLs — never javascript:, data:, etc.
            $safe = (bool)preg_match('#^(https?://|item\.php\?|commentary\.php\?)#i', $target);
            if (!$safe) {
                return $m[0]; // leave the literal text alone if the target looks unsafe
            }
            $external = str_starts_with($target, 'http');
            $relAttr = $external ? ' target="_blank" rel="noopener noreferrer"' : '';
            return '<a href="' . $target . '"' . $relAttr . '>' . $label . '</a>';
        },
        $escaped
    );

    $escaped = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $escaped);

    $paragraphs = preg_split('/\n{2,}/', trim($escaped));
    $html = array_map(fn($p) => '<p>' . nl2br($p) . '</p>', $paragraphs);
    return implode("\n", $html);
}

function domain_label(string $code): string
{
    return DOMAINS[$code]['label'] ?? $code;
}

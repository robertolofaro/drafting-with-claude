<?php
/**
 * db.php — PDO connections + small, reusable data-access helpers shared by
 * every page. All SQL here is portable between SQLite/MySQL/Postgres; the
 * only SQLite-specific thing in the whole webapp is the DSN in config.php.
 */

declare(strict_types=1);
require_once __DIR__ . '/../config.php';

function source_db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(SOURCE_DB_DSN, SOURCE_DB_USER, SOURCE_DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

function app_db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(APP_DB_DSN, APP_DB_USER, APP_DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        if (str_starts_with(APP_DB_DSN, 'sqlite:')) {
            $pdo->exec('PRAGMA foreign_keys = ON');
        }
    }
    return $pdo;
}

/** Validate a domain code against the DOMAINS whitelist. Returns null if invalid. */
function valid_domain(?string $code): ?string
{
    if ($code === null) {
        return null;
    }
    return array_key_exists($code, DOMAINS) ? $code : null;
}

/** The most recent files.brief_date available in the source DB, or null. */
function latest_brief_date(): ?string
{
    $row = source_db()->query('SELECT MAX(brief_date) AS d FROM files')->fetch();
    return $row['d'] ?? null;
}

/** files row for a given brief_date (picks the most recently imported one if several same-day files exist). */
function file_for_date(string $briefDate): ?array
{
    $stmt = source_db()->prepare(
        'SELECT * FROM files WHERE brief_date = ? ORDER BY imported_at DESC LIMIT 1'
    );
    $stmt->execute([$briefDate]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Items for one domain and one file_id, newest item_number order.
 * $table must already be validated via valid_domain()/DOMAINS — never pass
 * raw user input here.
 */
function items_for_domain(string $domainCode, int $fileId, int $limit = 0): array
{
    $table = DOMAINS[$domainCode]['table'];
    $sql = "SELECT * FROM {$table} WHERE file_id = ? ORDER BY item_number ASC";
    if ($limit > 0) {
        $sql .= ' LIMIT ' . $limit;
    }
    $stmt = source_db()->prepare($sql);
    $stmt->execute([$fileId]);
    return $stmt->fetchAll();
}

/** A single item by its natural key. */
function find_item(string $domainCode, int $fileId, int $itemNumber): ?array
{
    $table = DOMAINS[$domainCode]['table'];
    $stmt = source_db()->prepare("SELECT * FROM {$table} WHERE file_id = ? AND item_number = ?");
    $stmt->execute([$fileId, $itemNumber]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Original source articles (title + url) behind one item, in display order. */
function item_sources_for(string $domainCode, int $fileId, int $itemNumber): array
{
    $stmt = source_db()->prepare(
        'SELECT s.source_title, s.source_date, u.url
         FROM item_sources s JOIN urls u ON u.id = s.url_id
         WHERE s.file_id = ? AND s.category = ? AND s.item_number = ?
         ORDER BY s.order_idx ASC'
    );
    $stmt->execute([$fileId, $domainCode, $itemNumber]);
    return $stmt->fetchAll();
}

/** Classifier themes attached to one item, if any. */
function item_themes_for(string $domainCode, int $fileId, int $itemNumber): array
{
    $table = DOMAINS[$domainCode]['table'];
    $stmt = source_db()->prepare(
        'SELECT DISTINCT theme FROM item_themes
         WHERE file_id = ? AND source_table = ? AND item_number = ?'
    );
    $stmt->execute([$fileId, $table, $itemNumber]);
    return array_column($stmt->fetchAll(), 'theme');
}

/** Distinct themes known to the source DB's classifier (for search filters). */
function source_themes(): array
{
    $rows = source_db()->query('SELECT DISTINCT theme FROM item_themes WHERE theme IS NOT NULL ORDER BY theme')->fetchAll();
    return array_column($rows, 'theme');
}

/** brief_title + digest_summary + top signal_board rows for a file — the "front page" blocks. */
function brief_overview(int $fileId): array
{
    $db = source_db();

    $stmt = $db->prepare('SELECT * FROM brief_title WHERE file_id = ? LIMIT 1');
    $stmt->execute([$fileId]);
    $title = $stmt->fetch() ?: null;

    $stmt = $db->prepare('SELECT * FROM digest_summary WHERE file_id = ? ORDER BY row_idx ASC');
    $stmt->execute([$fileId]);
    $digest = $stmt->fetchAll();

    $stmt = $db->prepare('SELECT * FROM signal_board WHERE file_id = ? ORDER BY row_idx ASC LIMIT 1');
    $stmt->execute([$fileId]);
    $signals = $stmt->fetch() ?: null;

    return ['title' => $title, 'digest' => $digest, 'signals' => $signals];
}

/**
 * Full-text-ish search across all 5 agent_* tables for one or all domains,
 * with optional date/theme/keyword filters. Mirrors commentary_app.py's
 * SourceDB.search() so both tools behave the same way.
 */
function search_source_items(
    ?string $date,
    ?string $domain,
    ?string $theme,
    ?string $keyword,
    int $limit = 300
): array {
    $domains = $domain ? [$domain] : array_keys(DOMAINS);
    $results = [];

    foreach ($domains as $code) {
        if (!array_key_exists($code, DOMAINS)) {
            continue;
        }
        $table = DOMAINS[$code]['table'];
        $sql = "SELECT a.file_id, a.item_number, a.title, a.summary, a.significance,
                       a.trend_raw, a.alert_raw, f.brief_date, f.source_tool
                FROM {$table} a JOIN files f ON f.id = a.file_id WHERE 1=1";
        $params = [];

        if ($date) {
            $sql .= ' AND f.brief_date = ?';
            $params[] = $date;
        }
        if ($keyword) {
            $sql .= ' AND (a.title LIKE ? OR a.summary LIKE ? OR a.significance LIKE ?)';
            $kw = '%' . $keyword . '%';
            array_push($params, $kw, $kw, $kw);
        }
        if ($theme) {
            $sql .= ' AND a.item_number IN (
                        SELECT item_number FROM item_themes
                        WHERE file_id = a.file_id AND source_table = ? AND theme = ?
                      )';
            array_push($params, $table, $theme);
        }
        $sql .= ' ORDER BY f.brief_date DESC, a.item_number ASC LIMIT ' . (int)$limit;

        $stmt = source_db()->prepare($sql);
        $stmt->execute($params);
        foreach ($stmt->fetchAll() as $row) {
            $row['category'] = $code;
            $results[] = $row;
        }
    }

    usort($results, fn($a, $b) => [$b['brief_date'], $b['category'], $b['item_number']]
        <=> [$a['brief_date'], $a['category'], $a['item_number']]);

    return array_slice($results, 0, $limit);
}

/** Published commentaries, newest first, optionally filtered by theme/date. */
function list_commentaries(?string $theme = null, ?string $date = null, bool $publishedOnly = true): array
{
    $sql = 'SELECT * FROM commentaries WHERE 1=1';
    $params = [];
    if ($publishedOnly) {
        $sql .= " AND status = 'published'";
    }
    if ($theme) {
        $sql .= ' AND theme_code = ?';
        $params[] = $theme;
    }
    if ($date) {
        $sql .= ' AND brief_date = ?';
        $params[] = $date;
    }
    $sql .= ' ORDER BY brief_date DESC, published_at DESC';
    $stmt = app_db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function find_commentary(int $id): ?array
{
    $stmt = app_db()->prepare('SELECT * FROM commentaries WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function commentary_items(int $commentaryId): array
{
    $stmt = app_db()->prepare('SELECT * FROM commentary_items WHERE commentary_id = ? ORDER BY order_idx ASC');
    $stmt->execute([$commentaryId]);
    return $stmt->fetchAll();
}

/** Keyword/theme/date search over published commentaries (full access only). */
function search_commentaries(?string $date, ?string $theme, ?string $keyword): array
{
    $sql = "SELECT * FROM commentaries WHERE status = 'published'";
    $params = [];
    if ($date) {
        $sql .= ' AND brief_date = ?';
        $params[] = $date;
    }
    if ($theme) {
        $sql .= ' AND theme_code = ?';
        $params[] = $theme;
    }
    if ($keyword) {
        $sql .= ' AND (headline LIKE ? OR teaser LIKE ? OR body_markdown LIKE ?)';
        $kw = '%' . $keyword . '%';
        array_push($params, $kw, $kw, $kw);
    }
    $sql .= ' ORDER BY brief_date DESC, published_at DESC';
    $stmt = app_db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function app_themes(): array
{
    $rows = app_db()->query("SELECT code, label FROM themes WHERE is_active = 1 ORDER BY label")->fetchAll();
    return $rows;
}

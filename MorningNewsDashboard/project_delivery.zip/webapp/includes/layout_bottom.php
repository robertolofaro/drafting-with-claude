</main>
<footer class="site">Source data updates weekly · Commentary by <?= h('roberto.lofaro@robertolofaro.com') ?></footer>
</body>
</html>

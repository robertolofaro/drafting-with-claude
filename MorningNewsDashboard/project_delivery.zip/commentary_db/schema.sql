-- =============================================================================
-- app.sqlite3  —  "second database" (editorial commentary + access control)
--
-- This database is written to by the Python commentary-entry app and read
-- (read-only) by the PHP dashboard. It NEVER touches the source database
-- (morning_news.sqlite3 / its weekly successors) — the two are joined only
-- in application code, by the natural key that the source DB already uses
-- for an "item":
--
--      (file_id, category, item_number)
--
-- where category is one of: CONFLICT | BUSINESS | EU_AFFAIRS | TECHNOLOGY | TRENDS
-- (uppercase, matching item_sources.category / item_themes.source_table mapping,
-- NOT the lowercase agent_* table name).
--
-- Design notes (see docs/ARCHITECTURE.md for the full rationale):
--   * A commentary references 1..N source items. Each reference caches the
--     item's title and an internal permalink at the moment it is confirmed,
--     so a commentary keeps reading correctly even if the source DB is later
--     reimported, pruned, or renumbered. The live (file_id,category,item_number)
--     triple is also kept, so the dashboard CAN re-resolve against the live
--     source row (fresher summary, updated trend, etc.) when it still exists.
--   * "theme" is a free catalogue seeded from the source DB's item_themes
--     distinct values (ai_tech_policy, diplomacy, energy_markets,
--     food_security, monetary_policy, ...) but editable/extensible here,
--     since your own editorial themes don't have to match the classifier's.
--   * Token/access-control tables live in this same file. They are not
--     "commentary" data, but they are dashboard-operational data owned by
--     you, not the weekly source feed, so they belong in the app DB rather
--     than a third file. Split them out later if you ever want to.
-- =============================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- Editorial themes catalogue (seeded from source DB, editable thereafter)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS themes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    code        TEXT NOT NULL UNIQUE,      -- e.g. 'energy_markets'
    label       TEXT NOT NULL,             -- e.g. 'Energy Markets'
    description TEXT,
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ---------------------------------------------------------------------------
-- Domains catalogue — mirrors the 5 agent_* categories, kept as a lookup
-- table (rather than a hardcoded enum) so a 6th domain added later to the
-- source pipeline doesn't require a schema change here.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS domains (
    code        TEXT PRIMARY KEY,          -- 'CONFLICT','BUSINESS','EU_AFFAIRS','TECHNOLOGY','TRENDS'
    label       TEXT NOT NULL,             -- 'Conflict','Business', ...
    agent_table TEXT NOT NULL              -- 'agent_conflict', 'agent_business', ...
);

INSERT OR IGNORE INTO domains (code, label, agent_table) VALUES
    ('CONFLICT',   'Conflict',    'agent_conflict'),
    ('BUSINESS',   'Business',    'agent_business'),
    ('EU_AFFAIRS', 'EU Affairs',  'agent_eu_affairs'),
    ('TECHNOLOGY', 'Technology',  'agent_technology'),
    ('TRENDS',     'Trends',      'agent_trends');

-- ---------------------------------------------------------------------------
-- Commentaries — your own editorial write-ups
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS commentaries (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    headline        TEXT NOT NULL,
    theme_code      TEXT REFERENCES themes(code) ON DELETE SET NULL,
    brief_date      TEXT NOT NULL,          -- YYYYMMDD, the source "as of" date this commentary covers
    teaser          TEXT NOT NULL DEFAULT '', -- short free-to-read snippet shown in the RESTRICTED dashboard
    body_markdown   TEXT NOT NULL,          -- full text, token-gated; item refs already resolved to
                                             -- markdown links [Title](internal-permalink) at save time
    status          TEXT NOT NULL DEFAULT 'draft'   -- 'draft' | 'published'
                        CHECK (status IN ('draft','published')),
    author          TEXT NOT NULL DEFAULT 'roberto.lofaro@robertolofaro.com',
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    published_at    TEXT
);

CREATE INDEX IF NOT EXISTS idx_commentaries_date   ON commentaries(brief_date);
CREATE INDEX IF NOT EXISTS idx_commentaries_theme  ON commentaries(theme_code);
CREATE INDEX IF NOT EXISTS idx_commentaries_status ON commentaries(status);

-- Items a commentary references, in display order. This is the join table
-- that lets the dashboard render "Title" as a link, and lets search find
-- a commentary by an item's domain/date even though that lives in the
-- *other* database.
CREATE TABLE IF NOT EXISTS commentary_items (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    commentary_id       INTEGER NOT NULL REFERENCES commentaries(id) ON DELETE CASCADE,
    order_idx           INTEGER NOT NULL DEFAULT 0,

    -- live key into the source DB (may go stale — always re-check before trusting)
    source_file_id      INTEGER NOT NULL,
    source_category     TEXT NOT NULL REFERENCES domains(code),
    source_item_number  INTEGER NOT NULL,

    -- cached at the moment the commentary was confirmed, so rendering never
    -- breaks even if the source row above disappears or is renumbered
    cached_title        TEXT NOT NULL,
    cached_brief_date   TEXT NOT NULL,      -- files.brief_date at cache time
    cached_permalink    TEXT NOT NULL,      -- e.g. 'item.php?file_id=263&category=CONFLICT&n=3'
    cached_source_url   TEXT,               -- first/primary external article URL, if any

    UNIQUE (commentary_id, source_file_id, source_category, source_item_number)
);

CREATE INDEX IF NOT EXISTS idx_citems_commentary ON commentary_items(commentary_id);
CREATE INDEX IF NOT EXISTS idx_citems_source ON commentary_items(source_file_id, source_category, source_item_number);

-- ---------------------------------------------------------------------------
-- Token / access-control system
--
-- Model: you sell "packages" of N credits. A redeemed token grants the
-- bearer a full-access SESSION for ACCESS_WINDOW_HOURS (see webapp config;
-- default 24h) and spends exactly 1 credit per NEW window opened — re-using
-- the dashboard within an already-open window costs nothing more. This is a
-- simple, defensible "day pass" model; see docs/ARCHITECTURE.md for how to
-- change it to "1 credit per login" or "1 credit per item view" instead.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS token_packages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,          -- e.g. '10-pack'
    credits         INTEGER NOT NULL CHECK (credits > 0),
    price_cents     INTEGER,                -- informational only; no payment processing here
    currency        TEXT DEFAULT 'EUR',
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS tokens (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    token_hash          TEXT NOT NULL UNIQUE,   -- SHA-256 of the token string; the plaintext is
                                                 -- never stored, only shown once at issuance
    package_id          INTEGER REFERENCES token_packages(id) ON DELETE SET NULL,
    credits_total       INTEGER NOT NULL CHECK (credits_total > 0),
    credits_remaining   INTEGER NOT NULL,
    issued_to           TEXT,                   -- optional note/email, your own record-keeping
    status              TEXT NOT NULL DEFAULT 'active'
                            CHECK (status IN ('active','revoked','exhausted')),
    issued_at           TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    expires_at          TEXT                    -- optional hard expiry, NULL = no expiry
);

CREATE INDEX IF NOT EXISTS idx_tokens_status ON tokens(status);

-- One row per access window actually opened (i.e. per credit spent) — the
-- audit trail, and what the dashboard checks to decide "is this browser
-- already inside a still-valid window" without re-spending a credit.
CREATE TABLE IF NOT EXISTS token_redemptions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    token_id        INTEGER NOT NULL REFERENCES tokens(id) ON DELETE CASCADE,
    session_id      TEXT NOT NULL,          -- PHP session id this window is bound to
    opened_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    expires_at      TEXT NOT NULL,          -- opened_at + ACCESS_WINDOW_HOURS
    ip_address      TEXT,
    credits_spent   INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_redemptions_session ON token_redemptions(session_id);
CREATE INDEX IF NOT EXISTS idx_redemptions_token   ON token_redemptions(token_id);

#!/usr/bin/env python3
"""
init_db.py — create/upgrade app.sqlite3 (the commentary + token database)
and seed its theme catalogue from the source database's item_themes table.

Usage:
    python3 init_db.py --app-db ./app.sqlite3 --source-db ./morning_news.sqlite3

Safe to re-run: schema.sql uses CREATE TABLE IF NOT EXISTS, and theme
seeding uses INSERT OR IGNORE, so running this again (e.g. after the source
DB's weekly update introduces a new theme) only adds what's missing.
"""
import argparse
import sqlite3
import sys
from pathlib import Path

SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def init_app_db(app_db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(app_db_path)
    con.execute("PRAGMA foreign_keys = ON")
    schema_sql = SCHEMA_PATH.read_text(encoding="utf-8")
    con.executescript(schema_sql)
    con.commit()
    return con


def seed_themes_from_source(app_con: sqlite3.Connection, source_db_path: str) -> int:
    """Copy distinct theme codes out of the source DB's item_themes table
    into the app DB's themes catalogue. A human-readable label is derived
    automatically (snake_case -> Title Case); edit labels afterwards in the
    app DB if you want nicer wording."""
    src = sqlite3.connect(source_db_path)
    try:
        rows = src.execute(
            "SELECT DISTINCT theme FROM item_themes WHERE theme IS NOT NULL ORDER BY theme"
        ).fetchall()
    except sqlite3.OperationalError as exc:
        print(f"warning: could not read item_themes from source DB: {exc}", file=sys.stderr)
        rows = []
    finally:
        src.close()

    inserted = 0
    for (theme_code,) in rows:
        label = theme_code.replace("_", " ").title()
        cur = app_con.execute(
            "INSERT OR IGNORE INTO themes (code, label) VALUES (?, ?)",
            (theme_code, label),
        )
        inserted += cur.rowcount
    app_con.commit()
    return inserted


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app-db", default="app.sqlite3", help="path to the app/commentary database to create or upgrade")
    parser.add_argument("--source-db", default="morning_news.sqlite3", help="path to the read-only source database, used only to seed themes")
    parser.add_argument("--skip-theme-seed", action="store_true", help="skip copying themes from the source DB")
    args = parser.parse_args()

    print(f"Initializing app DB schema at: {args.app_db}")
    con = init_app_db(args.app_db)

    if not args.skip_theme_seed:
        if Path(args.source_db).exists():
            n = seed_themes_from_source(con, args.source_db)
            print(f"Seeded {n} new theme(s) from source DB item_themes.")
        else:
            print(f"warning: source DB not found at {args.source_db}, skipping theme seed.", file=sys.stderr)

    themes = con.execute("SELECT code, label FROM themes ORDER BY code").fetchall()
    print(f"\nThemes catalogue ({len(themes)}):")
    for code, label in themes:
        print(f"  - {code:20s} {label}")

    con.close()
    print("\nDone.")


if __name__ == "__main__":
    main()

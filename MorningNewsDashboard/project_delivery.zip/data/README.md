Put your databases here (this directory is intentionally not checked into
version control / not included in the delivered zip):

  data/morning_news.sqlite3   <- the source database (you already have it)
  data/app.sqlite3            <- created by commentary_db/init_db.py

See the top-level README.md and docs/ARCHITECTURE.md for setup steps.

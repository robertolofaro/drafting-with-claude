# Architecture & design decisions

This project has three parts that stay cleanly separated:

1. **Source database** (`morning_news.sqlite3`, or whatever you name its
   weekly successor) — the attached database. Read-only, from the dashboard's
   point of view. Updated by your own ingestion pipeline on whatever cadence
   you run it.
2. **Commentary app** (`commentary_app/`) — a local Python/Tkinter desktop
   tool you run on your own machine. Reads the source DB, writes to...
3. **App database** (`app.sqlite3`) — your editorial commentary, theme
   catalogue, and the token/access-control system. Read-write from the
   Python app, read-only from the PHP dashboard.
4. **PHP dashboard** (`webapp/`) — reads *both* databases and never writes
   to either.

Nothing ever writes to the source database. That keeps "my own commentary"
and "the weekly feed" from ever colliding, and means you can blow away and
reimport the source DB at any time without touching your editorial work.

## Why the item "key" is (file_id, category, item_number)

The source DB doesn't give each news item a single global ID — an item is
identified by which file (`files.id`, one row per ingested daily/weekly
brief) it came from, which of the five `agent_*` domain tables it's in
(`CONFLICT` / `BUSINESS` / `EU_AFFAIRS` / `TECHNOLOGY` / `TRENDS`), and its
`item_number` within that file+domain. `item_sources`, `item_themes` and
`item_classifications` all key off the same triple. The commentary app and
PHP dashboard both adopt it rather than inventing a parallel ID scheme.

Every place that turns a `category` into a table name (`agent_conflict` etc.)
does so through a small **whitelist** (`DOMAINS` in both
`commentary_app.py` and `webapp/config.php`) — raw user/URL input is always
validated against that whitelist before it ever touches a SQL string, since
table names can't be bound as query parameters.

## Why commentary caches title + permalink instead of only storing the key

`commentary_items` stores both the live key (`source_file_id`,
`source_category`, `source_item_number`) **and** a cached `cached_title` /
`cached_permalink` / `cached_source_url`, captured at the moment you confirm
a commentary in the Python app. This means:

- A commentary already published keeps reading correctly even if a later
  source DB rebuild renumbers `file_id`, or the row is pruned.
- The PHP dashboard never needs to re-join against the source DB just to
  render a commentary's reference list — it reads `commentary_items`
  directly, which is cheap and always available even if the source DB file
  is temporarily missing/locked during its weekly update.
- The live key is still there if you ever want to build a "re-check /
  refresh this reference" admin tool later.

## What "a link to the item (i.e. the summary)" means here

A commentary's body references items as markdown links:
`[Item title](item.php?file_id=...&category=...&n=...)`. That link is an
**internal** permalink into the PHP dashboard's own item detail page
(`item.php`), which shows the item's full summary, significance, trend, and
its original external source articles (pulled from `item_sources`/`urls`).
It is not a link straight to an external news site — the source items don't
carry their own single canonical URL (they can have several, via
`item_sources`), so the dashboard's own item page is the stable thing to
link to, and it's also where the paywall/token gate actually lives.

The Python app enforces this at **save time**: typing `[[ref:2]]` in the
body and hitting Preview resolves it to the real markdown link using the
2nd item you've added to the "selected items" list; anything left
unresolved (a typo'd reference number) blocks saving until fixed.

## The two-tier (restricted / full) model

- **Restricted** (no token): latest brief headline-level overview (title
  block, digest counts, signal board), a handful of items per domain with
  *truncated* summaries and no significance/sources, and commentary
  *teasers* only (`commentaries.teaser`, always free).
- **Full** (valid token redeemed): everything above in full, every item's
  complete summary + significance + original sources, the complete
  commentary body with links resolved, and the cross-database search
  (`search.php`) filterable by keyword / domain / theme / date.

This is enforced in exactly one place per page: `require_full_access()` in
`includes/auth.php`, called at the top of `item.php` and `search.php`
(when a query is present), and an `if (has_full_access())` branch inside
`index.php` / `commentary.php` that only changes *how much* is rendered,
not whether the page loads at all (so the restricted dashboard stays
genuinely useful on its own, per "restricted version (main information)").

## Token / credit model, and how to change it

Implemented as a **day-pass**: redeeming a valid token with ≥1 credit
remaining opens a "full access window" for `ACCESS_WINDOW_HOURS` (24h by
default, see `config.php`) and spends exactly **one** credit. Returning
within that window — even after closing the browser, since the PHP session
cookie lifetime is extended to match the window — costs nothing more.
That's `has_full_access()` / `redeem_token()` in `includes/auth.php`, and
the audit trail is `token_redemptions` (one row per window actually
opened).

This was chosen over two alternatives because it's the simplest to reason
about and matches "packages of N credits, each use removes one token":

- **Per-login** (every redemption spends a credit, no window) — change
  `redeem_token()` to always spend regardless of `has_full_access()`, and
  drop the window-reuse check.
- **Per-item-view** (spend a credit per `item.php` open) — move the spend
  logic out of `redeem_token()`/`unlock.php` and into `item.php` itself,
  tracking remaining "free" views per window.

Tokens are stored **hashed only** (SHA-256, in `tokens.token_hash`); the
plaintext token is shown exactly once, at `admin/issue_token.php mint`, and
cannot be recovered afterwards. Treat it like a password you're handing to
the buyer.

**No payment processing is included.** `token_packages` / `tokens` are
deliberately decoupled from any specific payment provider — `price_cents`
is informational only. The natural integration point is a webhook handler
(e.g. Stripe `checkout.session.completed`) that calls the same logic as
`admin/issue_token.php mint` and emails/displays the plaintext token to the
buyer. That's a separate, self-contained piece of work once you've picked a
processor.

## Deployment layout

```
project/
  data/                     <- OUTSIDE the webroot. Put morning_news.sqlite3
                               and app.sqlite3 here (config.php expects them
                               as siblings of webapp/).
  commentary_db/             schema.sql, init_db.py
  commentary_app/            commentary_app.py (runs on YOUR machine, not the server)
  webapp/
    config.php                <- outside the webroot too, or at least blocked
    includes/                 <- outside the webroot, or blocked
    admin/                    <- CLI-only; block entirely over HTTP (see below)
    public/                   <- THIS is your webserver's document root
      index.php, item.php, search.php, commentary.php, unlock.php
      assets/
```

Point your webserver's document root at `webapp/public/` only. `config.php`,
`includes/`, `admin/` and `data/` sit one level up and are never served
directly — `public/*.php` reach them with `require_once __DIR__ .
'/../includes/...'`, a filesystem path, not a URL. If your hosting can only
serve one flat directory (shared hosting with no choice of docroot), add
deny rules for `/config.php`, `/includes/`, `/admin/`, `/data/` in
`.htaccess` (Apache) or the nginx `location` block, and additionally keep
`admin/issue_token.php` restricted to CLI (`PHP_SAPI !== 'cli'` already
guards this, but defense in depth is still worth it).

## Running it locally end to end

```bash
# 1. one-time: create the app DB and seed its theme catalogue
cd commentary_db
python3 init_db.py --app-db ../data/app.sqlite3 --source-db ../data/morning_news.sqlite3

# 2. write some commentary
cd ../commentary_app
python3 commentary_app.py --source-db ../data/morning_news.sqlite3 --app-db ../data/app.sqlite3

# 3. mint a token to test the full dashboard
cd ../webapp/admin
php issue_token.php create-package "10-pack" 10 2900 EUR
php issue_token.php mint 1 "me"      # prints the plaintext token once

# 4. serve the dashboard
cd ../public
php -S 127.0.0.1:8099
# visit http://127.0.0.1:8099/ — restricted view
# visit http://127.0.0.1:8099/unlock.php and paste the minted token
```

## Swapping the source DB to MySQL/Postgres later

Every query in `webapp/includes/db.php` and `commentary_app.py`'s `SourceDB`
uses plain, portable SQL (parameterized `WHERE`/`JOIN`/`LIKE`/`ORDER BY` —
no SQLite-only functions). On the PHP side, the only change needed is
`SOURCE_DB_DSN`/`SOURCE_DB_USER`/`SOURCE_DB_PASS` in `config.php` (examples
for MySQL are already commented in there). On the Python side, `SourceDB`
would need its `sqlite3.connect(...)` swapped for a DB-API driver
(`mysql.connector`/`psycopg2`) behind the same method signatures — the
`search()`/`available_dates()`/etc. call sites in the UI don't change.

## Known v1 simplifications (documented, not accidental)

- **Search result cap**: `search_source_items()` / `search.php` cap results
  at 200–300 rows with no pagination yet. Broad keywords (e.g. a term that's
  been in the news for months) can hit that cap. Easy to add
  `LIMIT/OFFSET` paging if/when it matters.
- **Session-bound access window**: the full-access window is tied to a PHP
  session, not an account. A reader who clears cookies or switches devices
  mid-window needs to re-enter the token (cheap to do — it doesn't spend a
  second credit as long as the token itself still shows the window as open
  server-side... actually it *would* currently spend a new credit on a new
  device, since the check is session-based, not token-based.  If you want a
  token to grant one *shared* access window across devices rather than one
  per browser session, change `has_full_access()` to check
  `token_redemptions` by `token_id` + cookie value instead of by
  `session_id`.
- **No rate limiting** on token redemption attempts (`unlock.php`). Fine at
  small scale; add a simple attempts-per-IP throttle before this is
  publicly exposed at volume.
- **Markdown subset**: `render_commentary_markdown()` only supports
  `[text](url)` links, `**bold**`, and paragraph breaks — intentionally
  minimal so it stays trivially safe (everything is HTML-escaped before any
  markup is reconstructed). Extend the regex set if you want more.

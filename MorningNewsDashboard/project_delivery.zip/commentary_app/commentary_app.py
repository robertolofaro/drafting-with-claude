#!/usr/bin/env python3
"""
commentary_app.py — local desktop app for writing editorial commentary that
references items from the (read-only) source intelligence database into the
(read-write) app/commentary database.

Workflow implemented, as requested:
  1. Search/browse the source DB (by date, domain, theme, keyword).
  2. Select one or more items to reference.
  3. Compose a commentary: headline, theme, teaser (free-to-read snippet),
     and a body where you insert references to selected items.
  4. PREVIEW — the app resolves every reference into its final markdown link
     (using the item's title and an internal dashboard permalink) and shows
     you exactly what will be saved.
  5. Only after reviewing the preview do you CONFIRM, which writes the
     commentary + its item references into app.sqlite3 in one transaction.

Run:
    python3 commentary_app.py \
        --source-db /path/to/morning_news.sqlite3 \
        --app-db    /path/to/app.sqlite3

Both paths default to files named morning_news.sqlite3 / app.sqlite3 in the
current directory, and can also be changed from the File menu at runtime.

Requires only the Python standard library (sqlite3, tkinter). On Linux,
tkinter may need to be installed separately from the OS package manager,
e.g. `sudo apt install python3-tk` (it ships built-in with the official
python.org installers for Windows and macOS).
"""
from __future__ import annotations

import argparse
import re
import sqlite3
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

REF_PATTERN = re.compile(r"\[\[ref:(\d+)\]\]")

# Domain (agent_*) catalogue — kept in sync with commentary_db/schema.sql's
# `domains` table. A 6th domain added to the source pipeline later just
# needs a line added here (and ideally also seeded into app.sqlite3's
# domains table, which init_db.py / the Python app does NOT auto-manage
# today — see docs/ARCHITECTURE.md).
DOMAINS = [
    ("ALL", "All domains", None),
    ("CONFLICT", "Conflict", "agent_conflict"),
    ("BUSINESS", "Business", "agent_business"),
    ("EU_AFFAIRS", "EU Affairs", "agent_eu_affairs"),
    ("TECHNOLOGY", "Technology", "agent_technology"),
    ("TRENDS", "Trends", "agent_trends"),
]
DOMAIN_TABLE = {code: table for code, _, table in DOMAINS if table}
DOMAIN_LABEL = {code: label for code, label, _ in DOMAINS}


# =============================================================================
# Data access
# =============================================================================

@dataclass
class SourceItem:
    file_id: int
    category: str          # 'CONFLICT' etc (uppercase)
    item_number: int
    title: str
    summary: str
    significance: str
    trend_raw: str
    alert_raw: str
    brief_date: str        # YYYYMMDD
    source_tool: str
    primary_url: Optional[str] = None

    @property
    def permalink(self) -> str:
        return f"item.php?file_id={self.file_id}&category={self.category}&n={self.item_number}"

    @property
    def display_date(self) -> str:
        if len(self.brief_date) == 8:
            return f"{self.brief_date[0:4]}-{self.brief_date[4:6]}-{self.brief_date[6:8]}"
        return self.brief_date


class SourceDB:
    """Read-only access to the weekly-updated intelligence database."""

    def __init__(self, path: str):
        self.path = path
        self.con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        self.con.row_factory = sqlite3.Row

    def close(self):
        self.con.close()

    def available_dates(self) -> list[str]:
        rows = self.con.execute(
            "SELECT DISTINCT brief_date FROM files WHERE brief_date IS NOT NULL ORDER BY brief_date DESC"
        ).fetchall()
        return [r[0] for r in rows]

    def available_themes(self) -> list[str]:
        rows = self.con.execute(
            "SELECT DISTINCT theme FROM item_themes WHERE theme IS NOT NULL ORDER BY theme"
        ).fetchall()
        return [r[0] for r in rows]

    def _primary_url(self, file_id: int, category: str, item_number: int) -> Optional[str]:
        row = self.con.execute(
            """SELECT u.url FROM item_sources s
               JOIN urls u ON u.id = s.url_id
               WHERE s.file_id=? AND s.category=? AND s.item_number=?
               ORDER BY s.order_idx ASC LIMIT 1""",
            (file_id, category, item_number),
        ).fetchone()
        return row[0] if row else None

    def search(
        self,
        date: Optional[str] = None,
        domain: Optional[str] = None,
        theme: Optional[str] = None,
        keyword: Optional[str] = None,
        limit: int = 300,
    ) -> list[SourceItem]:
        domains = [domain] if domain and domain != "ALL" else list(DOMAIN_TABLE.keys())
        results: list[SourceItem] = []

        for category in domains:
            table = DOMAIN_TABLE[category]
            sql = [
                f"SELECT a.file_id, a.item_number, a.title, a.summary, a.significance,",
                f"       a.trend_raw, a.alert_raw, f.brief_date, f.source_tool",
                f"FROM {table} a JOIN files f ON f.id = a.file_id",
                f"WHERE 1=1",
            ]
            params: list = []
            if date:
                sql.append("AND f.brief_date = ?")
                params.append(date)
            if keyword:
                sql.append("AND (a.title LIKE ? OR a.summary LIKE ? OR a.significance LIKE ?)")
                kw = f"%{keyword}%"
                params.extend([kw, kw, kw])
            if theme:
                sql.append(
                    """AND a.item_number IN (
                         SELECT item_number FROM item_themes
                         WHERE file_id = a.file_id AND source_table = ? AND theme = ?
                       )"""
                )
                params.extend([table, theme])
            sql.append("ORDER BY f.brief_date DESC, a.item_number ASC")
            sql.append(f"LIMIT {int(limit)}")

            rows = self.con.execute("\n".join(sql), params).fetchall()
            for r in rows:
                results.append(
                    SourceItem(
                        file_id=r["file_id"],
                        category=category,
                        item_number=r["item_number"],
                        title=r["title"] or "(untitled)",
                        summary=r["summary"] or "",
                        significance=r["significance"] or "",
                        trend_raw=r["trend_raw"] or "",
                        alert_raw=r["alert_raw"] or "",
                        brief_date=r["brief_date"] or "",
                        source_tool=r["source_tool"] or "",
                    )
                )

        results.sort(key=lambda it: (it.brief_date, it.category, it.item_number), reverse=True)
        return results[:limit]

    def fill_primary_url(self, item: SourceItem) -> None:
        item.primary_url = self._primary_url(item.file_id, item.category, item.item_number)


class AppDB:
    """Read-write access to the commentary/token database."""

    def __init__(self, path: str):
        self.path = path
        self.con = sqlite3.connect(path)
        self.con.row_factory = sqlite3.Row
        self.con.execute("PRAGMA foreign_keys = ON")

    def close(self):
        self.con.close()

    def themes(self) -> list[tuple[str, str]]:
        rows = self.con.execute(
            "SELECT code, label FROM themes WHERE is_active=1 ORDER BY label"
        ).fetchall()
        return [(r["code"], r["label"]) for r in rows]

    def list_commentaries(self) -> list[sqlite3.Row]:
        return self.con.execute(
            """SELECT id, headline, theme_code, brief_date, status, updated_at
               FROM commentaries ORDER BY updated_at DESC"""
        ).fetchall()

    def load_commentary(self, commentary_id: int):
        c = self.con.execute(
            "SELECT * FROM commentaries WHERE id=?", (commentary_id,)
        ).fetchone()
        items = self.con.execute(
            """SELECT * FROM commentary_items
               WHERE commentary_id=? ORDER BY order_idx ASC""",
            (commentary_id,),
        ).fetchall()
        return c, items

    def delete_commentary(self, commentary_id: int) -> None:
        self.con.execute("DELETE FROM commentaries WHERE id=?", (commentary_id,))
        self.con.commit()

    def save_commentary(
        self,
        *,
        commentary_id: Optional[int],
        headline: str,
        theme_code: Optional[str],
        brief_date: str,
        teaser: str,
        body_markdown: str,
        status: str,
        selected_items: list[SourceItem],
    ) -> int:
        """Insert or update a commentary + its item references, atomically."""
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        cur = self.con.cursor()
        try:
            if commentary_id is None:
                cur.execute(
                    """INSERT INTO commentaries
                       (headline, theme_code, brief_date, teaser, body_markdown, status, created_at, updated_at,
                        published_at)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (
                        headline, theme_code, brief_date, teaser, body_markdown, status, now, now,
                        now if status == "published" else None,
                    ),
                )
                commentary_id = cur.lastrowid
            else:
                cur.execute(
                    """UPDATE commentaries SET headline=?, theme_code=?, brief_date=?, teaser=?,
                       body_markdown=?, status=?, updated_at=?,
                       published_at = CASE WHEN ?='published' AND published_at IS NULL THEN ? ELSE published_at END
                       WHERE id=?""",
                    (headline, theme_code, brief_date, teaser, body_markdown, status, now, status, now, commentary_id),
                )
                cur.execute("DELETE FROM commentary_items WHERE commentary_id=?", (commentary_id,))

            for idx, item in enumerate(selected_items):
                cur.execute(
                    """INSERT INTO commentary_items
                       (commentary_id, order_idx, source_file_id, source_category, source_item_number,
                        cached_title, cached_brief_date, cached_permalink, cached_source_url)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (
                        commentary_id, idx, item.file_id, item.category, item.item_number,
                        item.title, item.brief_date, item.permalink, item.primary_url,
                    ),
                )
            self.con.commit()
            return commentary_id
        except Exception:
            self.con.rollback()
            raise


# =============================================================================
# Reference resolution (shared by Preview and Save)
# =============================================================================

def resolve_body(body_text: str, selected_items: list[SourceItem]) -> str:
    """Replace every [[ref:N]] (1-based index into selected_items) with a
    markdown link to that item's title + internal dashboard permalink."""

    def _sub(m: re.Match) -> str:
        idx = int(m.group(1))
        if 1 <= idx <= len(selected_items):
            item = selected_items[idx - 1]
            return f"[{item.title}]({item.permalink})"
        return m.group(0)  # leave unresolved refs visible rather than silently dropping them

    return REF_PATTERN.sub(_sub, body_text)


def unresolved_refs(body_text: str, selected_items: list[SourceItem]) -> list[int]:
    bad = []
    for m in REF_PATTERN.finditer(body_text):
        idx = int(m.group(1))
        if not (1 <= idx <= len(selected_items)):
            bad.append(idx)
    return bad


# =============================================================================
# UI
# =============================================================================

class CommentaryApp(tk.Tk):
    def __init__(self, source_db_path: str, app_db_path: str):
        super().__init__()
        self.title("Commentary Entry — local editorial tool")
        self.geometry("1280x820")

        self.source_db_path = source_db_path
        self.app_db_path = app_db_path
        self.source: Optional[SourceDB] = None
        self.app: Optional[AppDB] = None

        self.selected_items: list[SourceItem] = []
        self.editing_commentary_id: Optional[int] = None

        self._build_menu()
        self._build_layout()
        self._open_databases()

    # ---- bootstrapping -----------------------------------------------------

    def _build_menu(self):
        menubar = tk.Menu(self)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open source DB...", command=self._choose_source_db)
        filemenu.add_command(label="Open app DB...", command=self._choose_app_db)
        filemenu.add_separator()
        filemenu.add_command(label="Quit", command=self.destroy)
        menubar.add_cascade(label="File", menu=filemenu)
        self.config(menu=menubar)

    def _choose_source_db(self):
        path = filedialog.askopenfilename(title="Select source database", filetypes=[("SQLite DB", "*.sqlite3 *.db"), ("All files", "*.*")])
        if path:
            self.source_db_path = path
            self._open_databases()

    def _choose_app_db(self):
        path = filedialog.askopenfilename(title="Select app/commentary database", filetypes=[("SQLite DB", "*.sqlite3 *.db"), ("All files", "*.*")])
        if path:
            self.app_db_path = path
            self._open_databases()

    def _open_databases(self):
        try:
            if self.source:
                self.source.close()
            if self.app:
                self.app.close()
            self.source = SourceDB(self.source_db_path)
            self.app = AppDB(self.app_db_path)
        except Exception as exc:
            messagebox.showerror("Database error", f"Could not open databases:\n{exc}")
            return
        self.status_var.set(f"Source: {self.source_db_path}   |   App: {self.app_db_path}")
        self._refresh_filter_choices()
        self._refresh_commentary_list()

    # ---- layout --------------------------------------------------------------

    def _build_layout(self):
        self.status_var = tk.StringVar(value="")
        status_bar = ttk.Label(self, textvariable=self.status_var, relief="sunken", anchor="w")
        status_bar.pack(side="bottom", fill="x")

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)

        self.compose_tab = ttk.Frame(notebook)
        self.manage_tab = ttk.Frame(notebook)
        notebook.add(self.compose_tab, text="Compose commentary")
        notebook.add(self.manage_tab, text="Manage commentaries")

        self._build_compose_tab(self.compose_tab)
        self._build_manage_tab(self.manage_tab)

    # ---- Compose tab -----------------------------------------------------

    def _build_compose_tab(self, parent):
        paned = ttk.PanedWindow(parent, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=6, pady=6)

        left = ttk.Frame(paned)
        right = ttk.Frame(paned)
        paned.add(left, weight=1)
        paned.add(right, weight=1)

        # --- Left: search & browse source items ---
        filt = ttk.LabelFrame(left, text="Search source items")
        filt.pack(fill="x", pady=(0, 6))

        ttk.Label(filt, text="Date").grid(row=0, column=0, sticky="w", padx=4, pady=2)
        self.date_cb = ttk.Combobox(filt, state="readonly", width=14)
        self.date_cb.grid(row=0, column=1, sticky="w", padx=4, pady=2)

        ttk.Label(filt, text="Domain").grid(row=0, column=2, sticky="w", padx=4, pady=2)
        self.domain_cb = ttk.Combobox(filt, state="readonly", width=14,
                                       values=[label for _, label, _ in DOMAINS])
        self.domain_cb.current(0)
        self.domain_cb.grid(row=0, column=3, sticky="w", padx=4, pady=2)

        ttk.Label(filt, text="Theme").grid(row=1, column=0, sticky="w", padx=4, pady=2)
        self.theme_cb = ttk.Combobox(filt, state="readonly", width=14)
        self.theme_cb.grid(row=1, column=1, sticky="w", padx=4, pady=2)

        ttk.Label(filt, text="Keyword").grid(row=1, column=2, sticky="w", padx=4, pady=2)
        self.keyword_entry = ttk.Entry(filt, width=18)
        self.keyword_entry.grid(row=1, column=3, sticky="w", padx=4, pady=2)
        self.keyword_entry.bind("<Return>", lambda e: self._run_search())

        ttk.Button(filt, text="Search", command=self._run_search).grid(row=0, column=4, rowspan=2, padx=8)

        results_frame = ttk.LabelFrame(left, text="Results (double-click to add)")
        results_frame.pack(fill="both", expand=True)

        cols = ("date", "domain", "n", "title", "trend")
        self.results_tree = ttk.Treeview(results_frame, columns=cols, show="headings", selectmode="extended")
        for c, w, label in [("date", 85, "Date"), ("domain", 90, "Domain"), ("n", 30, "#"),
                             ("title", 420, "Title"), ("trend", 90, "Trend")]:
            self.results_tree.heading(c, text=label)
            self.results_tree.column(c, width=w, stretch=(c == "title"))
        self.results_tree.pack(fill="both", expand=True, side="left")
        self.results_tree.bind("<Double-1>", lambda e: self._add_selected_results())

        rscroll = ttk.Scrollbar(results_frame, orient="vertical", command=self.results_tree.yview)
        self.results_tree.configure(yscrollcommand=rscroll.set)
        rscroll.pack(side="right", fill="y")

        self.detail_text = tk.Text(left, height=6, wrap="word")
        self.detail_text.pack(fill="x", pady=(4, 0))
        self.detail_text.configure(state="disabled")
        self.results_tree.bind("<<TreeviewSelect>>", self._show_item_detail)

        ttk.Button(left, text="Add selected to commentary ↓", command=self._add_selected_results).pack(fill="x", pady=4)

        # --- Right: composer ---
        meta = ttk.LabelFrame(right, text="Commentary")
        meta.pack(fill="x")

        ttk.Label(meta, text="Headline").grid(row=0, column=0, sticky="w", padx=4, pady=2)
        self.headline_entry = ttk.Entry(meta, width=60)
        self.headline_entry.grid(row=0, column=1, columnspan=3, sticky="we", padx=4, pady=2)

        ttk.Label(meta, text="Theme").grid(row=1, column=0, sticky="w", padx=4, pady=2)
        self.commentary_theme_cb = ttk.Combobox(meta, state="readonly", width=20)
        self.commentary_theme_cb.grid(row=1, column=1, sticky="w", padx=4, pady=2)

        ttk.Label(meta, text="Brief date (YYYYMMDD)").grid(row=1, column=2, sticky="w", padx=4, pady=2)
        self.brief_date_entry = ttk.Entry(meta, width=12)
        self.brief_date_entry.grid(row=1, column=3, sticky="w", padx=4, pady=2)
        self.brief_date_entry.insert(0, datetime.now().strftime("%Y%m%d"))

        ttk.Label(meta, text="Teaser (free, shown without a token)").grid(row=2, column=0, sticky="nw", padx=4, pady=2)
        self.teaser_text = tk.Text(meta, height=3, width=60, wrap="word")
        self.teaser_text.grid(row=2, column=1, columnspan=3, sticky="we", padx=4, pady=2)

        sel_frame = ttk.LabelFrame(right, text="Selected items (referenced via [[ref:N]])")
        sel_frame.pack(fill="x", pady=4)
        self.selected_list = tk.Listbox(sel_frame, height=5)
        self.selected_list.pack(fill="x", side="left", expand=True, padx=(4, 0), pady=4)
        sel_btns = ttk.Frame(sel_frame)
        sel_btns.pack(side="right", fill="y", padx=4)
        ttk.Button(sel_btns, text="Insert ref", command=self._insert_ref).pack(fill="x", pady=1)
        ttk.Button(sel_btns, text="Remove", command=self._remove_selected_item).pack(fill="x", pady=1)
        ttk.Button(sel_btns, text="Up", command=lambda: self._move_selected_item(-1)).pack(fill="x", pady=1)
        ttk.Button(sel_btns, text="Down", command=lambda: self._move_selected_item(1)).pack(fill="x", pady=1)

        body_frame = ttk.LabelFrame(right, text="Body (markdown; use the Insert ref button to cite items)")
        body_frame.pack(fill="both", expand=True)
        self.body_text = tk.Text(body_frame, wrap="word", undo=True)
        self.body_text.pack(fill="both", expand=True, padx=4, pady=4)

        action_bar = ttk.Frame(right)
        action_bar.pack(fill="x", pady=4)
        ttk.Button(action_bar, text="New / Clear", command=self._clear_composer).pack(side="left", padx=2)
        ttk.Button(action_bar, text="Preview…", command=self._open_preview).pack(side="left", padx=2)
        ttk.Button(action_bar, text="Save as draft", command=lambda: self._save(status="draft")).pack(side="right", padx=2)
        ttk.Button(action_bar, text="Confirm & publish", command=self._confirm_and_publish).pack(side="right", padx=2)

    # ---- Manage tab --------------------------------------------------------

    def _build_manage_tab(self, parent):
        top = ttk.Frame(parent)
        top.pack(fill="x", padx=6, pady=6)
        ttk.Button(top, text="Refresh", command=self._refresh_commentary_list).pack(side="left")
        ttk.Button(top, text="Edit selected", command=self._edit_selected_commentary).pack(side="left", padx=4)
        ttk.Button(top, text="Delete selected", command=self._delete_selected_commentary).pack(side="left", padx=4)

        cols = ("id", "date", "theme", "status", "headline", "updated")
        self.commentary_tree = ttk.Treeview(parent, columns=cols, show="headings")
        for c, w, label in [("id", 40, "ID"), ("date", 85, "Date"), ("theme", 120, "Theme"),
                             ("status", 80, "Status"), ("headline", 450, "Headline"), ("updated", 160, "Updated")]:
            self.commentary_tree.heading(c, text=label)
            self.commentary_tree.column(c, width=w, stretch=(c == "headline"))
        self.commentary_tree.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        self.commentary_tree.bind("<Double-1>", lambda e: self._edit_selected_commentary())

    # ---- behavior: search --------------------------------------------------

    def _refresh_filter_choices(self):
        dates = self.source.available_dates()
        self.date_cb["values"] = ["All dates"] + dates
        self.date_cb.current(0)

        themes = self.source.available_themes()
        self.theme_cb["values"] = ["All themes"] + themes
        self.theme_cb.current(0)

        app_themes = self.app.themes()
        self.commentary_theme_cb["values"] = [f"{label} ({code})" for code, label in app_themes]
        self._app_theme_codes = [code for code, _ in app_themes]
        if app_themes:
            self.commentary_theme_cb.current(0)

    def _selected_domain_code(self) -> Optional[str]:
        label = self.domain_cb.get()
        for code, lbl, _ in DOMAINS:
            if lbl == label:
                return code
        return "ALL"

    def _run_search(self):
        date = self.date_cb.get()
        date = None if date in ("", "All dates") else date
        domain = self._selected_domain_code()
        theme = self.theme_cb.get()
        theme = None if theme in ("", "All themes") else theme
        keyword = self.keyword_entry.get().strip() or None

        try:
            items = self.source.search(date=date, domain=domain, theme=theme, keyword=keyword)
        except Exception as exc:
            messagebox.showerror("Search error", str(exc))
            return

        self.results_tree.delete(*self.results_tree.get_children())
        self._last_results: dict[str, SourceItem] = {}
        for item in items:
            iid = f"{item.file_id}:{item.category}:{item.item_number}"
            self._last_results[iid] = item
            self.results_tree.insert("", "end", iid=iid, values=(
                item.display_date, DOMAIN_LABEL.get(item.category, item.category),
                item.item_number, item.title, item.trend_raw,
            ))
        self.status_var.set(f"{len(items)} item(s) found.")

    def _show_item_detail(self, _event=None):
        sel = self.results_tree.selection()
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", "end")
        if sel:
            item = self._last_results.get(sel[-1])
            if item:
                self.source.fill_primary_url(item)
                text = f"{item.title}\n\nSummary: {item.summary}\n\nSignificance: {item.significance}"
                if item.primary_url:
                    text += f"\n\nPrimary source: {item.primary_url}"
                self.detail_text.insert("1.0", text)
        self.detail_text.configure(state="disabled")

    # ---- behavior: selection / composer ------------------------------------

    def _add_selected_results(self):
        sel = self.results_tree.selection()
        for iid in sel:
            item = self._last_results.get(iid)
            if not item:
                continue
            key = (item.file_id, item.category, item.item_number)
            if any((it.file_id, it.category, it.item_number) == key for it in self.selected_items):
                continue
            self.source.fill_primary_url(item)
            self.selected_items.append(item)
        self._refresh_selected_list()

    def _refresh_selected_list(self):
        self.selected_list.delete(0, "end")
        for i, item in enumerate(self.selected_items, start=1):
            self.selected_list.insert("end", f"[{i}] {item.display_date} · {DOMAIN_LABEL.get(item.category)} · {item.title}")

    def _remove_selected_item(self):
        sel = self.selected_list.curselection()
        for idx in reversed(sel):
            del self.selected_items[idx]
        self._refresh_selected_list()

    def _move_selected_item(self, delta: int):
        sel = self.selected_list.curselection()
        if not sel:
            return
        idx = sel[0]
        new_idx = idx + delta
        if 0 <= new_idx < len(self.selected_items):
            self.selected_items[idx], self.selected_items[new_idx] = self.selected_items[new_idx], self.selected_items[idx]
            self._refresh_selected_list()
            self.selected_list.selection_set(new_idx)

    def _insert_ref(self):
        sel = self.selected_list.curselection()
        if not sel:
            messagebox.showinfo("Insert reference", "Select an item in the 'Selected items' list first.")
            return
        idx = sel[0] + 1  # 1-based
        self.body_text.insert("insert", f"[[ref:{idx}]]")
        self.body_text.focus_set()

    def _clear_composer(self):
        self.editing_commentary_id = None
        self.headline_entry.delete(0, "end")
        self.teaser_text.delete("1.0", "end")
        self.body_text.delete("1.0", "end")
        self.brief_date_entry.delete(0, "end")
        self.brief_date_entry.insert(0, datetime.now().strftime("%Y%m%d"))
        self.selected_items = []
        self._refresh_selected_list()

    # ---- behavior: preview / save -----------------------------------------

    def _collect_form(self):
        headline = self.headline_entry.get().strip()
        brief_date = self.brief_date_entry.get().strip()
        teaser = self.teaser_text.get("1.0", "end").strip()
        body = self.body_text.get("1.0", "end").strip()

        theme_label = self.commentary_theme_cb.get()
        theme_code = None
        if theme_label and getattr(self, "_app_theme_codes", None):
            try:
                idx = list(self.commentary_theme_cb["values"]).index(theme_label)
                theme_code = self._app_theme_codes[idx]
            except ValueError:
                pass
        return headline, theme_code, brief_date, teaser, body

    def _validate_form(self, headline, brief_date, body) -> Optional[str]:
        if not headline:
            return "Headline is required."
        if not re.fullmatch(r"\d{8}", brief_date or ""):
            return "Brief date must be YYYYMMDD."
        if not body:
            return "Body text is required."
        bad = unresolved_refs(body, self.selected_items)
        if bad:
            return f"Body references [[ref:N]] that don't match a selected item: {bad}"
        return None

    def _open_preview(self):
        headline, theme_code, brief_date, teaser, body = self._collect_form()
        err = self._validate_form(headline, brief_date, body)
        resolved = resolve_body(body, self.selected_items)

        win = tk.Toplevel(self)
        win.title("Preview — review before confirming")
        win.geometry("760x640")

        if err:
            ttk.Label(win, text=f"⚠ {err}", foreground="red").pack(fill="x", padx=8, pady=4)

        ttk.Label(win, text=headline or "(no headline)", font=("TkDefaultFont", 14, "bold")).pack(fill="x", padx=8, pady=(8, 0))
        ttk.Label(win, text=f"Theme: {theme_code or '(none)'}   ·   Date: {brief_date}").pack(fill="x", padx=8)

        ttk.Label(win, text="Teaser (free):", font=("TkDefaultFont", 10, "bold")).pack(fill="x", padx=8, pady=(8, 0))
        t1 = tk.Text(win, height=3, wrap="word")
        t1.insert("1.0", teaser)
        t1.configure(state="disabled")
        t1.pack(fill="x", padx=8)

        ttk.Label(win, text="Body, with references resolved to links (token-gated):", font=("TkDefaultFont", 10, "bold")).pack(fill="x", padx=8, pady=(8, 0))
        t2 = tk.Text(win, wrap="word")
        t2.insert("1.0", resolved)
        t2.configure(state="disabled")
        t2.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        ttk.Label(win, text="Referenced items:", font=("TkDefaultFont", 10, "bold")).pack(fill="x", padx=8)
        refs = tk.Text(win, height=min(6, max(2, len(self.selected_items))), wrap="word")
        for i, item in enumerate(self.selected_items, start=1):
            refs.insert("end", f"[{i}] {item.title}  →  {item.permalink}\n")
        refs.configure(state="disabled")
        refs.pack(fill="x", padx=8, pady=(0, 8))

        if not err:
            btns = ttk.Frame(win)
            btns.pack(fill="x", padx=8, pady=8)
            ttk.Button(btns, text="Looks good — confirm & publish", command=lambda: (win.destroy(), self._confirm_and_publish())).pack(side="right")
            ttk.Button(btns, text="Keep editing", command=win.destroy).pack(side="right", padx=6)

    def _save(self, status: str):
        headline, theme_code, brief_date, teaser, body = self._collect_form()
        err = self._validate_form(headline, brief_date, body)
        if err:
            messagebox.showerror("Cannot save", err)
            return
        resolved_body = resolve_body(body, self.selected_items)
        try:
            cid = self.app.save_commentary(
                commentary_id=self.editing_commentary_id,
                headline=headline, theme_code=theme_code, brief_date=brief_date,
                teaser=teaser, body_markdown=resolved_body, status=status,
                selected_items=self.selected_items,
            )
        except Exception as exc:
            messagebox.showerror("Save failed", str(exc))
            return
        self.editing_commentary_id = cid
        self.status_var.set(f"Saved commentary #{cid} as {status}.")
        self._refresh_commentary_list()
        if status == "published":
            messagebox.showinfo("Published", f"Commentary #{cid} saved and published.")

    def _confirm_and_publish(self):
        headline, theme_code, brief_date, teaser, body = self._collect_form()
        err = self._validate_form(headline, brief_date, body)
        if err:
            messagebox.showerror("Cannot publish", err)
            return
        if not messagebox.askyesno("Confirm publish", "Write this commentary into the app database now?"):
            return
        self._save(status="published")

    # ---- behavior: manage tab ----------------------------------------------

    def _refresh_commentary_list(self):
        if not self.app:
            return
        self.commentary_tree.delete(*self.commentary_tree.get_children())
        for row in self.app.list_commentaries():
            self.commentary_tree.insert("", "end", iid=str(row["id"]), values=(
                row["id"], row["brief_date"], row["theme_code"] or "", row["status"], row["headline"], row["updated_at"],
            ))

    def _edit_selected_commentary(self):
        sel = self.commentary_tree.selection()
        if not sel:
            return
        cid = int(sel[0])
        c, items = self.app.load_commentary(cid)
        if not c:
            return
        self._clear_composer()
        self.editing_commentary_id = cid
        self.headline_entry.insert(0, c["headline"])
        self.brief_date_entry.delete(0, "end")
        self.brief_date_entry.insert(0, c["brief_date"])
        self.teaser_text.insert("1.0", c["teaser"])
        self.body_text.insert("1.0", c["body_markdown"])

        if c["theme_code"] and getattr(self, "_app_theme_codes", None) and c["theme_code"] in self._app_theme_codes:
            idx = self._app_theme_codes.index(c["theme_code"])
            self.commentary_theme_cb.current(idx)

        self.selected_items = []
        for r in items:
            self.selected_items.append(SourceItem(
                file_id=r["source_file_id"], category=r["source_category"], item_number=r["source_item_number"],
                title=r["cached_title"], summary="", significance="", trend_raw="", alert_raw="",
                brief_date=r["cached_brief_date"], source_tool="", primary_url=r["cached_source_url"],
            ))
        self._refresh_selected_list()

        notebook = self.compose_tab.master
        notebook.select(self.compose_tab)

    def _delete_selected_commentary(self):
        sel = self.commentary_tree.selection()
        if not sel:
            return
        cid = int(sel[0])
        if messagebox.askyesno("Delete commentary", f"Permanently delete commentary #{cid}?"):
            self.app.delete_commentary(cid)
            self._refresh_commentary_list()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--source-db", default="morning_news.sqlite3")
    parser.add_argument("--app-db", default="app.sqlite3")
    args = parser.parse_args()

    if not Path(args.app_db).exists():
        print(f"App DB not found at {args.app_db} — run commentary_db/init_db.py first.", file=sys.stderr)

    app = CommentaryApp(args.source_db, args.app_db)
    app.mainloop()


if __name__ == "__main__":
    main()

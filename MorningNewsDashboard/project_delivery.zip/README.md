# Morning Brief — commentary & dashboard

Three pieces, see `docs/ARCHITECTURE.md` for the full design rationale:

- **`commentary_db/`** — schema + init script for `app.sqlite3`, the
  database that holds your editorial commentary and the token/access system.
- **`commentary_app/`** — a local Python/Tkinter desktop app: search the
  source database, select items, write a commentary that references them,
  preview the resolved links, confirm to save.
- **`webapp/`** — the PHP dashboard: a free restricted view (headlines,
  trend direction, commentary teasers) and a token-gated full view (full
  summaries, sources, commentary, and cross-database search).

Tested end-to-end against the `morning_news.sqlite3` database you provided
(263 briefs, ~3,450 items across the 5 domains) — schema creation, search
with every filter combination, commentary save/preview/edit, token minting,
redemption, credit decrement, and all five PHP pages in both restricted and
full-access mode.

## Quickstart

```bash
mkdir -p data
cp /path/to/morning_news.sqlite3 data/morning_news.sqlite3

cd commentary_db
python3 init_db.py --app-db ../data/app.sqlite3 --source-db ../data/morning_news.sqlite3
cd ..

cd commentary_app
python3 commentary_app.py --source-db ../data/morning_news.sqlite3 --app-db ../data/app.sqlite3
cd ..

cd webapp/admin
php issue_token.php create-package "10-pack" 10 2900 EUR
php issue_token.php mint 1 "me"
cd ../public
php -S 127.0.0.1:8099
```

Then open http://127.0.0.1:8099/ for the restricted view, and
http://127.0.0.1:8099/unlock.php to redeem the token minted above.

## Requirements

- Python 3.9+ with Tkinter (stdlib on Windows/macOS; on Linux you may need
  `sudo apt install python3-tk` or your distro's equivalent) for the
  commentary app. No third-party packages.
- PHP 8.1+ with the `pdo_sqlite` extension (bundled by default in most PHP
  builds) for the dashboard. No Composer dependencies.

## What's next (not built, by design — see docs/ARCHITECTURE.md)

- Payment processor integration (Stripe/PayPal/etc.) to auto-mint tokens on
  purchase — `admin/issue_token.php mint` is the function to call from
  whatever webhook handler you add.
- Pagination on the full-access search results.
- A nicer visual design pass on the PHP templates (current CSS is clean but
  plain, deliberately, so you can restyle without fighting generated markup).

# PM Extractor

A small offline tool that pulls an **instantaneous snapshot** of a project
/ program / initiative from either **Jira** or a self-hosted **dotProject**
(MySQL/MariaDB) instance, loads it into a fresh local `transit.sqlite3`
database, lets you attach commentary on that specific pull, and packages
everything into a ZIP for your downstream integration/reporting/ML
pipelines.

It does not keep history itself — each run is a clean, disposable
snapshot of "what the source looked like right now." Your other
pipelines are responsible for archiving/trending across snapshots.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

On Debian/Ubuntu you may also need `sudo apt install python3-tk` (Tkinter
ships with Python on Windows/macOS, but is a separate package on some
Linux distros).

## Configure your scopes

Copy `config/scopes.example.yaml` to your own file (e.g.
`config/scopes.yaml`) and fill in real values — one entry per
project/program/initiative ("scope"):

- `type: jira` scopes need `base_url`, `deployment` (`cloud` or
  `server`), `auth`, and a default `jql`.
  - Cloud: `auth.email` + `auth.api_token`.
  - Server/Data Center: `auth.personal_access_token`, or
    `auth.username` + `auth.password`.
- `type: dotproject` scopes need DB connection details plus one or more
  named SQL queries (`queries:`), and optionally an `attachments` block
  if you want files copied out of dotProject's upload folder.

Because every dotProject install here is a customized fork, the tool
makes **no assumption about table/column names** — you write the SQL
yourself, per scope, and each named query becomes its own table in the
output database.

This file holds credentials in clear text, as requested. Keep it out of
version control / shared drives, and set restrictive permissions:

```bash
chmod 600 config/scopes.yaml
```

## Run

```bash
python main.py config/scopes.yaml --author "Roberto Lofaro"
```

(or just `python main.py` and use "Load config file..." in the GUI).

### The four manual steps

1. **Parameters** — pick a scope, review/edit the JQL (Jira) or the named
   SQL queries (dotProject), toggle attachment retrieval. "Test
   connection" buttons let you validate credentials before committing.
   Click **Confirm parameters** to lock these in and unlock step 2.
2. **Build DB** — choose an output folder, then **Build fresh database**.
   This deletes any existing `transit.sqlite3` in that folder, creates a
   new one, runs the retrieval, and downloads/copies attachments into an
   `attachments/` subfolder. Record counts and attachment counts are
   written into the database itself.
3. **Commentary** — enter free-text notes on this particular pull. Saved
   alongside the selection criteria (the exact JQL/SQL used) and the
   retrieval stats, all timestamped.
4. **Package** — choose (or accept the suggested) ZIP path and click
   **Generate ZIP**. The ZIP contains `transit.sqlite3`, the
   `attachments/` folder (if any), and a small `manifest.json`.

After step 4, hand the ZIP off to whatever else you run manually.

## transit.sqlite3 schema

Fixed tables (always present):

| Table | Purpose |
|---|---|
| `meta` | scope name/type, retrieval timestamp, schema version |
| `selection_criteria` | the exact JQL / SQL used per query, timestamped |
| `retrieval_stats` | record/attachment counts and duration per query |
| `commentary` | your step-3 free-text notes, with author + timestamp |
| `jira_issues` | normalized core fields (one row per issue) |
| `jira_issues_raw` | full raw issue JSON, for full fidelity |
| `jira_attachments` | attachment metadata + local file path |
| `dotproject_attachments` | attachment metadata + local file path + copy status |

Dynamic tables (dotProject only): one table per named query, called
`dp_<query_name>`, with columns mirroring that query's result set.

## Notes / things you'll likely want to adapt

- **Jira pagination** uses the standard `startAt`/`maxResults` REST
  search loop; `max_results_per_page` in the config controls page size.
- **Jira attachments** are downloaded via the `content` URL on each
  issue's `fields.attachment` entries, into `attachments/<ISSUE-KEY>/`.
- **dotProject attachments** assume files live on a filesystem path
  (local disk or a mounted share) you specify as `attachments.base_path`;
  the tool only *copies* them out, it doesn't go over SFTP/HTTP. If your
  fork serves files differently (e.g. through a download script, or a
  BLOB column), adjust `fetch_attachments()` in
  `app/dotproject_source.py`.
- Everything is **read-only** against both source systems — no writes,
  no status updates, nothing pushed back.
- All retrieval calls run synchronously in the GUI thread for simplicity;
  for very large pulls you'll see the window "freeze" during the fetch —
  progress is still written to the log panel as it happens (page by page
  / query by query).

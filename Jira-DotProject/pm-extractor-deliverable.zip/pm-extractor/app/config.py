"""
Loads scopes.yaml into typed Scope objects.

A "scope" is one project / program / initiative, with everything the
extractor needs to connect and pull data: which backend (jira |
dotproject), its retrieval parameters (JQL or SQL queries), and its
credentials.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


class ConfigError(Exception):
    pass


@dataclass
class JiraScopeConfig:
    deployment: str                      # "cloud" | "server"
    base_url: str
    auth: Dict[str, str]
    jql: str
    fields: List[str] = field(default_factory=list)
    download_attachments: bool = True
    max_results_per_page: int = 100


@dataclass
class DotProjectAttachmentsConfig:
    enabled: bool = False
    query: str = ""
    file_path_column: str = ""
    folder_column: Optional[str] = None
    base_path: str = ""


@dataclass
class DotProjectScopeConfig:
    host: str
    port: int
    database: str
    user: str
    password: str
    queries: Dict[str, str]
    charset: str = "utf8mb4"
    attachments: Optional[DotProjectAttachmentsConfig] = None


@dataclass
class Scope:
    name: str
    type: str                            # "jira" | "dotproject"
    jira: Optional[JiraScopeConfig] = None
    dotproject: Optional[DotProjectScopeConfig] = None
    raw: Dict[str, Any] = field(default_factory=dict)  # original dict, for editing/round-trip


def _require(d: Dict[str, Any], key: str, where: str) -> Any:
    if key not in d or d[key] in (None, ""):
        raise ConfigError(f"Missing required key '{key}' in {where}")
    return d[key]


def _parse_jira(d: Dict[str, Any], scope_name: str) -> JiraScopeConfig:
    where = f"scope '{scope_name}'.jira"
    auth = _require(d, "auth", where)
    deployment = d.get("deployment", "cloud")
    if deployment not in ("cloud", "server"):
        raise ConfigError(f"{where}.deployment must be 'cloud' or 'server', got {deployment!r}")
    return JiraScopeConfig(
        deployment=deployment,
        base_url=_require(d, "base_url", where).rstrip("/"),
        auth=auth,
        jql=_require(d, "jql", where),
        fields=d.get("fields", []),
        download_attachments=bool(d.get("download_attachments", True)),
        max_results_per_page=int(d.get("max_results_per_page", 100)),
    )


def _parse_dotproject(d: Dict[str, Any], scope_name: str) -> DotProjectScopeConfig:
    where = f"scope '{scope_name}'.dotproject"
    queries = _require(d, "queries", where)
    if not isinstance(queries, dict) or not queries:
        raise ConfigError(f"{where}.queries must be a non-empty mapping of name -> SQL")

    attachments_cfg = None
    att = d.get("attachments")
    if att:
        attachments_cfg = DotProjectAttachmentsConfig(
            enabled=bool(att.get("enabled", False)),
            query=att.get("query", ""),
            file_path_column=att.get("file_path_column", ""),
            folder_column=att.get("folder_column"),
            base_path=att.get("base_path", ""),
        )
        if attachments_cfg.enabled:
            if not attachments_cfg.query or not attachments_cfg.file_path_column:
                raise ConfigError(
                    f"{where}.attachments is enabled but missing 'query' or 'file_path_column'"
                )

    return DotProjectScopeConfig(
        host=_require(d, "host", where),
        port=int(d.get("port", 3306)),
        database=_require(d, "database", where),
        user=_require(d, "user", where),
        password=d.get("password", ""),
        queries=queries,
        charset=d.get("charset", "utf8mb4"),
        attachments=attachments_cfg,
    )


def parse_scope(d: Dict[str, Any]) -> Scope:
    name = _require(d, "name", "scope")
    stype = _require(d, "type", f"scope '{name}'")
    if stype not in ("jira", "dotproject"):
        raise ConfigError(f"scope '{name}'.type must be 'jira' or 'dotproject', got {stype!r}")

    scope = Scope(name=name, type=stype, raw=copy.deepcopy(d))
    if stype == "jira":
        scope.jira = _parse_jira(_require(d, "jira", f"scope '{name}'"), name)
    else:
        scope.dotproject = _parse_dotproject(_require(d, "dotproject", f"scope '{name}'"), name)
    return scope


def load_scopes(path: str | Path) -> List[Scope]:
    path = Path(path)
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    scopes_raw = data.get("scopes")
    if not isinstance(scopes_raw, list) or not scopes_raw:
        raise ConfigError("Config file must contain a non-empty 'scopes' list")

    scopes = [parse_scope(s) for s in scopes_raw]

    names = [s.name for s in scopes]
    dupes = {n for n in names if names.count(n) > 1}
    if dupes:
        raise ConfigError(f"Duplicate scope name(s) in config: {', '.join(sorted(dupes))}")

    return scopes

"""
Builds the "transit.sqlite3" snapshot database.

This DB is meant to be a disposable, instantaneous snapshot: step 2 always
deletes any existing file at the target path and creates a brand new one.
History/trending lives elsewhere (your downstream pipelines); this file
only ever represents "what the source system looked like at retrieval
time", plus your commentary on that specific pull.

Fixed tables:
  meta                 - one row per retrieval: scope, type, timestamp...
  selection_criteria    - the JQL / SQL used, per query, with a timestamp
  retrieval_stats        - record counts / attachment counts / duration
  commentary             - free-text notes entered in step 3
  jira_issues             - normalized core fields, one row per Jira issue
  jira_issues_raw          - full raw issue JSON, for full fidelity
  jira_attachments          - attachment metadata + local file path
  dotproject_attachments     - attachment metadata + local file path

Dynamic tables:
  dp_<query_name>  - one table per dotProject named query, columns
                     mirroring the SQL result set (step 1's queries)
"""
from __future__ import annotations

import json
import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .dotproject_source import QueryResult

SCHEMA_VERSION = 1


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _sql_ident(name: str) -> str:
    """Make a safe-ish SQLite identifier from a free-text query name."""
    safe = "".join(c if (c.isalnum() or c == "_") else "_" for c in name.strip())
    if not safe or safe[0].isdigit():
        safe = f"q_{safe}"
    return safe


def _infer_sqlite_type(value: Any) -> str:
    if isinstance(value, bool):
        return "INTEGER"
    if isinstance(value, int):
        return "INTEGER"
    if isinstance(value, float):
        return "REAL"
    if isinstance(value, (bytes, bytearray)):
        return "BLOB"
    return "TEXT"


def _coerce_value(value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return json.dumps(value, default=str, ensure_ascii=False)
    if isinstance(value, datetime):
        return value.isoformat()
    return value


class TransitDB:
    def __init__(self, path: str):
        self.path = path
        self.conn: Optional[sqlite3.Connection] = None

    # ------------------------------------------------------------------
    def create_fresh(self, scope_name: str, scope_type: str) -> None:
        """Deletes any existing file at self.path and (re)creates schema."""
        if os.path.exists(self.path):
            os.remove(self.path)
        os.makedirs(os.path.dirname(os.path.abspath(self.path)) or ".", exist_ok=True)

        self.conn = sqlite3.connect(self.path)
        self.conn.execute("PRAGMA foreign_keys = ON")
        cur = self.conn.cursor()

        cur.execute("""
            CREATE TABLE meta (
                key   TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE selection_criteria (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                source      TEXT NOT NULL,      -- 'jira' | 'dotproject'
                label       TEXT NOT NULL,      -- e.g. 'jql', 'tasks', 'milestones'
                criteria    TEXT NOT NULL,       -- the JQL / SQL text actually used
                recorded_at TEXT NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE retrieval_stats (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                source           TEXT NOT NULL,
                label            TEXT NOT NULL,
                record_count     INTEGER NOT NULL,
                attachment_count INTEGER NOT NULL DEFAULT 0,
                duration_seconds REAL,
                recorded_at      TEXT NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE commentary (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                author     TEXT,
                created_at TEXT NOT NULL,
                comment    TEXT NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE jira_issues (
                issue_key   TEXT PRIMARY KEY,
                issue_id    TEXT,
                project_key TEXT,
                summary     TEXT,
                status      TEXT,
                issuetype   TEXT,
                priority    TEXT,
                assignee    TEXT,
                reporter    TEXT,
                created     TEXT,
                updated     TEXT,
                duedate     TEXT,
                resolution  TEXT,
                parent_key  TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE jira_issues_raw (
                issue_key TEXT PRIMARY KEY,
                raw_json  TEXT NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE jira_attachments (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                issue_key     TEXT NOT NULL,
                attachment_id TEXT,
                filename      TEXT,
                local_path    TEXT,
                size          INTEGER,
                mime_type     TEXT,
                author        TEXT,
                created       TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE dotproject_attachments (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                filename          TEXT,
                local_path        TEXT,
                copy_status       TEXT,       -- ok | missing | skipped
                source_base_path  TEXT,
                source_path_tried TEXT,
                row_json          TEXT
            )
        """)

        self.conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)",
            ("schema_version", str(SCHEMA_VERSION)),
        )
        self.conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)",
            ("scope_name", scope_name),
        )
        self.conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)",
            ("scope_type", scope_type),
        )
        self.conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)",
            ("retrieved_at", _now_iso()),
        )
        self.conn.commit()

    # ------------------------------------------------------------------
    def open_existing(self) -> None:
        """Reopens an already-built transit DB (e.g. for step 3's commentary)."""
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"transit DB not found: {self.path}")
        self.conn = sqlite3.connect(self.path)
        self.conn.execute("PRAGMA foreign_keys = ON")

    # ------------------------------------------------------------------
    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        self.conn.commit()

    # ------------------------------------------------------------------
    def write_selection_criteria(self, source: str, label: str, criteria: str) -> None:
        self.conn.execute(
            "INSERT INTO selection_criteria (source, label, criteria, recorded_at) "
            "VALUES (?, ?, ?, ?)",
            (source, label, criteria, _now_iso()),
        )
        self.conn.commit()

    def write_stats(
        self,
        source: str,
        label: str,
        record_count: int,
        attachment_count: int = 0,
        duration_seconds: Optional[float] = None,
    ) -> None:
        self.conn.execute(
            "INSERT INTO retrieval_stats "
            "(source, label, record_count, attachment_count, duration_seconds, recorded_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (source, label, record_count, attachment_count, duration_seconds, _now_iso()),
        )
        self.conn.commit()

    def write_commentary(self, comment: str, author: Optional[str] = None) -> None:
        self.conn.execute(
            "INSERT INTO commentary (author, created_at, comment) VALUES (?, ?, ?)",
            (author, _now_iso(), comment),
        )
        self.conn.commit()

    # ------------------------------------------------------------------
    # Jira
    # ------------------------------------------------------------------
    def write_jira_issues(self, issues: List[Dict[str, Any]]) -> None:
        cur = self.conn.cursor()
        for issue in issues:
            fields = issue.get("fields") or {}

            def field_name(f):
                v = fields.get(f)
                if isinstance(v, dict):
                    return v.get("name") or v.get("displayName") or v.get("key")
                return v

            cur.execute(
                """
                INSERT INTO jira_issues (
                    issue_key, issue_id, project_key, summary, status, issuetype,
                    priority, assignee, reporter, created, updated, duedate,
                    resolution, parent_key
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(issue_key) DO UPDATE SET
                    issue_id=excluded.issue_id, project_key=excluded.project_key,
                    summary=excluded.summary, status=excluded.status,
                    issuetype=excluded.issuetype, priority=excluded.priority,
                    assignee=excluded.assignee, reporter=excluded.reporter,
                    created=excluded.created, updated=excluded.updated,
                    duedate=excluded.duedate, resolution=excluded.resolution,
                    parent_key=excluded.parent_key
                """,
                (
                    issue.get("key"),
                    issue.get("id"),
                    (fields.get("project") or {}).get("key"),
                    fields.get("summary"),
                    field_name("status"),
                    field_name("issuetype"),
                    field_name("priority"),
                    field_name("assignee"),
                    field_name("reporter"),
                    fields.get("created"),
                    fields.get("updated"),
                    fields.get("duedate"),
                    field_name("resolution"),
                    (fields.get("parent") or {}).get("key"),
                ),
            )
            cur.execute(
                "INSERT INTO jira_issues_raw (issue_key, raw_json) VALUES (?, ?) "
                "ON CONFLICT(issue_key) DO UPDATE SET raw_json = excluded.raw_json",
                (issue.get("key"), json.dumps(issue, default=str, ensure_ascii=False)),
            )
        self.conn.commit()

    def write_jira_attachments(self, records: List[Dict[str, Any]]) -> None:
        cur = self.conn.cursor()
        for r in records:
            cur.execute(
                """
                INSERT INTO jira_attachments
                    (issue_key, attachment_id, filename, local_path, size,
                     mime_type, author, created)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    r.get("issue_key"), r.get("attachment_id"), r.get("filename"),
                    r.get("local_path"), r.get("size"), r.get("mime_type"),
                    r.get("author"), r.get("created"),
                ),
            )
        self.conn.commit()

    # ------------------------------------------------------------------
    # dotProject
    # ------------------------------------------------------------------
    def write_dotproject_query_result(self, result: QueryResult) -> str:
        """Creates (or replaces) table dp_<name> and loads the rows into it.
        Returns the actual table name used."""
        table = f"dp_{_sql_ident(result.name)}"
        cur = self.conn.cursor()
        cur.execute(f'DROP TABLE IF EXISTS "{table}"')

        if not result.rows:
            # still create an (empty) table with whatever columns we know of
            cols = result.columns or ["value"]
            col_defs = ", ".join(f'"{_sql_ident(c)}" TEXT' for c in cols)
            cur.execute(f'CREATE TABLE "{table}" ({col_defs})')
            self.conn.commit()
            return table

        columns = result.columns or list(result.rows[0].keys())
        first_row = result.rows[0]
        col_defs = ", ".join(
            f'"{_sql_ident(c)}" {_infer_sqlite_type(first_row.get(c))}' for c in columns
        )
        cur.execute(f'CREATE TABLE "{table}" ({col_defs})')

        placeholders = ", ".join("?" for _ in columns)
        col_list = ", ".join(f'"{_sql_ident(c)}"' for c in columns)
        insert_sql = f'INSERT INTO "{table}" ({col_list}) VALUES ({placeholders})'

        cur.executemany(
            insert_sql,
            [tuple(_coerce_value(row.get(c)) for c in columns) for row in result.rows],
        )
        self.conn.commit()
        return table

    def write_dotproject_attachments(self, records: List[Dict[str, Any]]) -> None:
        cur = self.conn.cursor()
        for r in records:
            row_copy = {
                k: v for k, v in r.items()
                if k not in ("filename", "local_path", "copy_status",
                             "source_base_path", "source_path_tried")
            }
            cur.execute(
                """
                INSERT INTO dotproject_attachments
                    (filename, local_path, copy_status, source_base_path,
                     source_path_tried, row_json)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    r.get("filename"), r.get("local_path"), r.get("copy_status"),
                    r.get("source_base_path"), r.get("source_path_tried"),
                    json.dumps(row_copy, default=str, ensure_ascii=False),
                ),
            )
        self.conn.commit()

    # ------------------------------------------------------------------
    def close(self) -> None:
        if self.conn:
            self.conn.close()
            self.conn = None

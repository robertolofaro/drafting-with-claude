"""
Minimal Tkinter wizard: 4 manual steps, one scope at a time.

  Step 1  Parameters   - pick/edit the JQL (Jira) or review/edit the named
                          SQL queries (dotProject), toggle attachments
  Step 2  Build DB      - delete+recreate transit.sqlite3, run the
                          retrieval, load results + download attachments
  Step 3  Commentary     - free-text note on this pull, stored with the
                          selection criteria and stats already captured
  Step 4  Package         - zip transit.sqlite3 + attachments/ together

Each step is a separate button the user presses; a step is only enabled
once the previous one has completed successfully for the currently loaded
scope. Switching scopes resets the wizard state.
"""
from __future__ import annotations

import os
import threading
import time
import traceback
from datetime import datetime
from tkinter import (
    BOTH, DISABLED, END, LEFT, NORMAL, RIGHT, Tk, X, Y,
    StringVar, Text, Toplevel, filedialog, messagebox,
)
from tkinter import ttk
from typing import Dict, List, Optional

from .config import ConfigError, Scope, load_scopes
from .db_builder import TransitDB
from .dotproject_source import DotProjectError, DotProjectSource, QueryResult
from .jira_source import JiraError, JiraSource
from .packager import build_zip, default_zip_name


class WizardState:
    """Per-scope working state, reset whenever the scope selection changes."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.step1_done = False
        self.step2_done = False
        self.step3_done = False
        self.step4_done = False

        # step 1 outputs
        self.jira_jql: Optional[str] = None
        self.jira_download_attachments: bool = True
        self.dp_queries: Dict[str, str] = {}
        self.dp_attachments_enabled: bool = False

        # step 2 outputs
        self.output_dir: Optional[str] = None
        self.db_path: Optional[str] = None
        self.attachments_dir: Optional[str] = None
        self.last_record_count: int = 0
        self.last_attachment_count: int = 0


class App:
    def __init__(self, root: Tk, config_path: Optional[str] = None, default_author: Optional[str] = None):
        self.root = root
        self.root.title("PM Extractor - Jira / dotProject -> transit.sqlite3")
        self.root.geometry("880x680")

        self.scopes: List[Scope] = []
        self.scope: Optional[Scope] = None
        self.state = WizardState()
        self.default_author = default_author or ""

        self._build_menu_bar()
        self._build_scope_bar()
        self._build_notebook()
        self._build_log_area()

        if config_path and os.path.exists(config_path):
            self._load_config(config_path)

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------
    def _build_menu_bar(self):
        bar = ttk.Frame(self.root, padding=6)
        bar.pack(fill=X)
        ttk.Button(bar, text="Load config file...", command=self._on_load_config).pack(side=LEFT)
        self.config_label_var = StringVar(value="No config loaded")
        ttk.Label(bar, textvariable=self.config_label_var).pack(side=LEFT, padx=10)

    def _build_scope_bar(self):
        bar = ttk.Frame(self.root, padding=(6, 0, 6, 6))
        bar.pack(fill=X)
        ttk.Label(bar, text="Scope:").pack(side=LEFT)
        self.scope_var = StringVar()
        self.scope_combo = ttk.Combobox(bar, textvariable=self.scope_var, state="readonly", width=60)
        self.scope_combo.pack(side=LEFT, padx=6)
        self.scope_combo.bind("<<ComboboxSelected>>", self._on_scope_selected)
        self.scope_type_var = StringVar(value="")
        ttk.Label(bar, textvariable=self.scope_type_var).pack(side=LEFT, padx=10)

    def _build_notebook(self):
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill=BOTH, expand=True, padx=6, pady=6)

        self.tab1 = ttk.Frame(self.nb, padding=10)
        self.tab2 = ttk.Frame(self.nb, padding=10)
        self.tab3 = ttk.Frame(self.nb, padding=10)
        self.tab4 = ttk.Frame(self.nb, padding=10)
        self.nb.add(self.tab1, text="1. Parameters")
        self.nb.add(self.tab2, text="2. Build DB")
        self.nb.add(self.tab3, text="3. Commentary")
        self.nb.add(self.tab4, text="4. Package")

        self._build_tab1()
        self._build_tab2()
        self._build_tab3()
        self._build_tab4()
        self._set_tabs_enabled(step1=False, step2=False, step3=False, step4=False)

    def _build_log_area(self):
        frame = ttk.LabelFrame(self.root, text="Log", padding=4)
        frame.pack(fill=X, padx=6, pady=(0, 6))
        self.log_text = Text(frame, height=8, state=DISABLED, wrap="word")
        self.log_text.pack(fill=X)

    # ---- Tab 1: parameters -------------------------------------------------
    def _build_tab1(self):
        self.tab1_jira_frame = ttk.Frame(self.tab1)
        self.tab1_dp_frame = ttk.Frame(self.tab1)

        # Jira widgets
        ttk.Label(self.tab1_jira_frame, text="JQL:").pack(anchor="w")
        self.jql_text = Text(self.tab1_jira_frame, height=4, wrap="word")
        self.jql_text.pack(fill=X)
        self.jira_fields_var = StringVar()
        ttk.Label(self.tab1_jira_frame, textvariable=self.jira_fields_var,
                  foreground="#555").pack(anchor="w", pady=(4, 0))
        self.jira_att_var = StringVar(value="1")
        ttk.Checkbutton(self.tab1_jira_frame, text="Download attachments",
                         variable=self.jira_att_var, onvalue="1", offvalue="0"
                         ).pack(anchor="w", pady=(8, 0))
        ttk.Button(self.tab1_jira_frame, text="Test Jira connection",
                   command=self._on_test_jira).pack(anchor="w", pady=(8, 0))

        # dotProject widgets
        ttk.Label(self.tab1_dp_frame, text="Named queries (edit SQL as needed):").pack(anchor="w")
        self.dp_query_list = ttk.Treeview(self.tab1_dp_frame, columns=("name",), show="headings", height=4)
        self.dp_query_list.heading("name", text="Query name")
        self.dp_query_list.pack(fill=X, pady=(2, 4))
        self.dp_query_list.bind("<<TreeviewSelect>>", self._on_dp_query_selected)

        self.dp_sql_text = Text(self.tab1_dp_frame, height=8, wrap="word")
        self.dp_sql_text.pack(fill=X)
        ttk.Button(self.tab1_dp_frame, text="Save edit to selected query",
                   command=self._on_dp_query_save).pack(anchor="w", pady=(4, 0))

        self.dp_att_var = StringVar(value="1")
        self.dp_att_check = ttk.Checkbutton(
            self.tab1_dp_frame, text="Retrieve attachments (per config)",
            variable=self.dp_att_var, onvalue="1", offvalue="0")
        self.dp_att_check.pack(anchor="w", pady=(8, 0))
        ttk.Button(self.tab1_dp_frame, text="Test dotProject connection",
                   command=self._on_test_dotproject).pack(anchor="w", pady=(8, 0))

        ttk.Button(self.tab1, text="Confirm parameters -> enable step 2",
                   command=self._on_confirm_step1).pack(anchor="w", pady=(12, 0))

        self._dp_query_cache: Dict[str, str] = {}
        self._dp_selected_query: Optional[str] = None

    # ---- Tab 2: build DB -----------------------------------------------
    def _build_tab2(self):
        ttk.Label(self.tab2, text="Output folder (will hold transit.sqlite3 and attachments/):"
                  ).pack(anchor="w")
        row = ttk.Frame(self.tab2)
        row.pack(fill=X, pady=(2, 10))
        self.output_dir_var = StringVar()
        ttk.Entry(row, textvariable=self.output_dir_var).pack(side=LEFT, fill=X, expand=True)
        ttk.Button(row, text="Browse...", command=self._on_browse_output_dir).pack(side=LEFT, padx=4)

        ttk.Button(self.tab2, text="Build fresh database (deletes any existing transit.sqlite3)",
                   command=self._on_build_db).pack(anchor="w")

        self.step2_summary_var = StringVar(value="")
        ttk.Label(self.tab2, textvariable=self.step2_summary_var, foreground="#555"
                  ).pack(anchor="w", pady=(10, 0))

    # ---- Tab 3: commentary ----------------------------------------------
    def _build_tab3(self):
        ttk.Label(self.tab3, text="Author:").pack(anchor="w")
        self.author_var = StringVar(value=self.default_author)
        ttk.Entry(self.tab3, textvariable=self.author_var, width=40).pack(anchor="w", pady=(0, 8))

        ttk.Label(self.tab3, text="Commentary on this selection/retrieval:").pack(anchor="w")
        self.commentary_text = Text(self.tab3, height=10, wrap="word")
        self.commentary_text.pack(fill=BOTH, expand=True, pady=(2, 8))

        ttk.Button(self.tab3, text="Save commentary -> enable step 4",
                   command=self._on_save_commentary).pack(anchor="w")

    # ---- Tab 4: package ---------------------------------------------------
    def _build_tab4(self):
        ttk.Label(self.tab4, text="Output ZIP file:").pack(anchor="w")
        row = ttk.Frame(self.tab4)
        row.pack(fill=X, pady=(2, 10))
        self.zip_path_var = StringVar()
        ttk.Entry(row, textvariable=self.zip_path_var).pack(side=LEFT, fill=X, expand=True)
        ttk.Button(row, text="Browse...", command=self._on_browse_zip_path).pack(side=LEFT, padx=4)

        ttk.Button(self.tab4, text="Generate ZIP", command=self._on_build_zip).pack(anchor="w")
        self.step4_summary_var = StringVar(value="")
        ttk.Label(self.tab4, textvariable=self.step4_summary_var, foreground="#555"
                  ).pack(anchor="w", pady=(10, 0))

    # ------------------------------------------------------------------
    # Logging helpers
    # ------------------------------------------------------------------
    def log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state=NORMAL)
        self.log_text.insert(END, f"[{ts}] {msg}\n")
        self.log_text.see(END)
        self.log_text.configure(state=DISABLED)
        self.root.update_idletasks()

    def _set_tabs_enabled(self, step1: bool, step2: bool, step3: bool, step4: bool):
        self.nb.tab(1, state=NORMAL if step1 else DISABLED)
        self.nb.tab(2, state=NORMAL if step2 else DISABLED)
        self.nb.tab(3, state=NORMAL if step3 else DISABLED)

    # ------------------------------------------------------------------
    # Config / scope loading
    # ------------------------------------------------------------------
    def _on_load_config(self):
        path = filedialog.askopenfilename(
            title="Select scopes config (YAML)",
            filetypes=[("YAML files", "*.yaml *.yml"), ("All files", "*.*")],
        )
        if path:
            self._load_config(path)

    def _load_config(self, path: str):
        try:
            self.scopes = load_scopes(path)
        except ConfigError as exc:
            messagebox.showerror("Config error", str(exc))
            return
        except Exception as exc:
            messagebox.showerror("Config error", f"Unexpected error: {exc}")
            return

        self.config_label_var.set(f"Loaded {len(self.scopes)} scope(s) from {os.path.basename(path)}")
        self.scope_combo["values"] = [s.name for s in self.scopes]
        if self.scopes:
            self.scope_combo.current(0)
            self._on_scope_selected()
        self.log(f"Loaded config: {path}")

    def _on_scope_selected(self, *_):
        name = self.scope_var.get()
        self.scope = next((s for s in self.scopes if s.name == name), None)
        self.state.reset()
        self._set_tabs_enabled(step1=True, step2=False, step3=False, step4=False)
        if not self.scope:
            return

        self.scope_type_var.set(f"type: {self.scope.type}")
        self.log(f"Scope selected: {self.scope.name} ({self.scope.type})")

        self.tab1_jira_frame.pack_forget()
        self.tab1_dp_frame.pack_forget()

        if self.scope.type == "jira":
            self.tab1_jira_frame.pack(fill=BOTH, expand=True)
            self.jql_text.delete("1.0", END)
            self.jql_text.insert("1.0", self.scope.jira.jql)
            self.jira_fields_var.set(
                "Fields: " + (", ".join(self.scope.jira.fields) if self.scope.jira.fields else "(default)")
            )
            self.jira_att_var.set("1" if self.scope.jira.download_attachments else "0")
        else:
            self.tab1_dp_frame.pack(fill=BOTH, expand=True)
            self._dp_query_cache = dict(self.scope.dotproject.queries)
            for row in self.dp_query_list.get_children():
                self.dp_query_list.delete(row)
            for qname in self._dp_query_cache:
                self.dp_query_list.insert("", END, iid=qname, values=(qname,))
            self.dp_sql_text.delete("1.0", END)
            self._dp_selected_query = None
            has_att = bool(self.scope.dotproject.attachments and self.scope.dotproject.attachments.enabled)
            self.dp_att_var.set("1" if has_att else "0")
            self.dp_att_check.configure(state=NORMAL if has_att else DISABLED)

        # reset downstream tabs' widgets
        self.output_dir_var.set("")
        self.step2_summary_var.set("")
        self.commentary_text.delete("1.0", END)
        self.zip_path_var.set("")
        self.step4_summary_var.set("")

    # ------------------------------------------------------------------
    # Step 1
    # ------------------------------------------------------------------
    def _on_dp_query_selected(self, *_):
        sel = self.dp_query_list.selection()
        if not sel:
            return
        if self._dp_selected_query:
            self._dp_query_cache[self._dp_selected_query] = self.dp_sql_text.get("1.0", END).strip()
        self._dp_selected_query = sel[0]
        self.dp_sql_text.delete("1.0", END)
        self.dp_sql_text.insert("1.0", self._dp_query_cache.get(self._dp_selected_query, ""))

    def _on_dp_query_save(self):
        if not self._dp_selected_query:
            messagebox.showinfo("No query selected", "Select a query from the list first.")
            return
        self._dp_query_cache[self._dp_selected_query] = self.dp_sql_text.get("1.0", END).strip()
        self.log(f"Updated SQL for query '{self._dp_selected_query}' (in-memory only).")

    def _on_test_jira(self):
        if not self.scope or self.scope.type != "jira":
            return
        try:
            src = JiraSource(self.scope.jira)
            who = src.test_connection()
            self.log(f"Jira connection OK - authenticated as: {who}")
            messagebox.showinfo("Jira", f"Connected OK.\nAuthenticated as: {who}")
        except JiraError as exc:
            self.log(f"Jira connection FAILED: {exc}")
            messagebox.showerror("Jira connection failed", str(exc))
        except Exception as exc:
            self.log(f"Jira connection FAILED: {exc}")
            messagebox.showerror("Jira connection failed", f"{exc}")

    def _on_test_dotproject(self):
        if not self.scope or self.scope.type != "dotproject":
            return
        try:
            with DotProjectSource(self.scope.dotproject) as src:
                msg = src.test_connection()
            self.log(f"dotProject connection OK - {msg}")
            messagebox.showinfo("dotProject", msg)
        except DotProjectError as exc:
            self.log(f"dotProject connection FAILED: {exc}")
            messagebox.showerror("dotProject connection failed", str(exc))
        except Exception as exc:
            self.log(f"dotProject connection FAILED: {exc}")
            messagebox.showerror("dotProject connection failed", f"{exc}")

    def _on_confirm_step1(self):
        if not self.scope:
            return
        if self.scope.type == "jira":
            self.state.jira_jql = self.jql_text.get("1.0", END).strip()
            self.state.jira_download_attachments = (self.jira_att_var.get() == "1")
            self.log(f"Step 1 confirmed (Jira). JQL = {self.state.jira_jql!r}")
        else:
            if self._dp_selected_query:
                self._dp_query_cache[self._dp_selected_query] = self.dp_sql_text.get("1.0", END).strip()
            self.state.dp_queries = dict(self._dp_query_cache)
            self.state.dp_attachments_enabled = (self.dp_att_var.get() == "1")
            self.log(f"Step 1 confirmed (dotProject). {len(self.state.dp_queries)} queries set.")

        self.state.step1_done = True
        self._set_tabs_enabled(step1=True, step2=True, step3=False, step4=False)
        self.nb.select(self.tab2)

    # ------------------------------------------------------------------
    # Step 2
    # ------------------------------------------------------------------
    def _on_browse_output_dir(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.output_dir_var.set(path)

    def _on_build_db(self):
        if not self.scope or not self.state.step1_done:
            messagebox.showinfo("Step 1 required", "Confirm parameters in step 1 first.")
            return
        output_dir = self.output_dir_var.get().strip()
        if not output_dir:
            messagebox.showinfo("Output folder required", "Choose an output folder first.")
            return
        os.makedirs(output_dir, exist_ok=True)

        db_path = os.path.join(output_dir, "transit.sqlite3")
        attachments_dir = os.path.join(output_dir, "attachments")

        try:
            self.log(f"Building fresh database at {db_path} ...")
            t0 = time.time()
            db = TransitDB(db_path)
            db.create_fresh(self.scope.name, self.scope.type)

            if self.scope.type == "jira":
                self._run_jira_retrieval(db, attachments_dir)
            else:
                self._run_dotproject_retrieval(db, attachments_dir)

            db.close()
            elapsed = time.time() - t0
            self.state.output_dir = output_dir
            self.state.db_path = db_path
            self.state.attachments_dir = attachments_dir if os.path.isdir(attachments_dir) else None
            self.state.step2_done = True

            self.step2_summary_var.set(
                f"Done in {elapsed:.1f}s. Records: {self.state.last_record_count}, "
                f"Attachments: {self.state.last_attachment_count}."
            )
            self.log(f"Step 2 complete. DB at {db_path}")
            self._set_tabs_enabled(step1=True, step2=True, step3=True, step4=False)
            self.nb.select(self.tab3)
        except (JiraError, DotProjectError) as exc:
            self.log(f"Step 2 FAILED: {exc}")
            messagebox.showerror("Retrieval failed", str(exc))
        except Exception as exc:
            self.log(f"Step 2 FAILED: {exc}\n{traceback.format_exc()}")
            messagebox.showerror("Retrieval failed", f"{exc}")

    def _run_jira_retrieval(self, db: TransitDB, attachments_dir: str):
        cfg = self.scope.jira
        src = JiraSource(cfg)

        self.log("Fetching issues from Jira...")

        def progress(done, total):
            self.log(f"  ...{done}/{total} issues fetched")

        result = src.fetch_issues(jql_override=self.state.jira_jql, progress_cb=progress)
        db.write_jira_issues(result.issues)
        db.write_selection_criteria("jira", "jql", result.jql_used)

        attachment_count = 0
        if self.state.jira_download_attachments:
            self.log("Downloading attachments...")

            def att_progress(done, total):
                if total:
                    self.log(f"  ...{done}/{total} attachments downloaded")

            records = src.download_attachments(result.issues, attachments_dir, progress_cb=att_progress)
            db.write_jira_attachments(records)
            attachment_count = len(records)

        db.write_stats("jira", "jql", record_count=len(result.issues),
                        attachment_count=attachment_count)
        self.state.last_record_count = len(result.issues)
        self.state.last_attachment_count = attachment_count
        self.log(f"Jira: {len(result.issues)} issues, {attachment_count} attachments.")

    def _run_dotproject_retrieval(self, db: TransitDB, attachments_dir: str):
        cfg = self.scope.dotproject
        total_records = 0
        with DotProjectSource(cfg) as src:
            self.log(f"Running {len(self.state.dp_queries)} dotProject queries...")
            results: List[QueryResult] = src.run_named_queries(self.state.dp_queries)
            for r in results:
                table = db.write_dotproject_query_result(r)
                db.write_selection_criteria("dotproject", r.name, r.sql_used)
                db.write_stats("dotproject", r.name, record_count=len(r.rows))
                total_records += len(r.rows)
                self.log(f"  '{r.name}' -> table {table}: {len(r.rows)} rows")

            attachment_count = 0
            if self.state.dp_attachments_enabled and cfg.attachments and cfg.attachments.enabled:
                self.log("Copying attachments from dotProject file store...")
                records = src.fetch_attachments(attachments_dir)
                db.write_dotproject_attachments(records)
                db.write_selection_criteria("dotproject", "attachments", cfg.attachments.query)
                attachment_count = len(records)
                ok = sum(1 for r in records if r.get("copy_status") == "ok")
                missing = sum(1 for r in records if r.get("copy_status") == "missing")
                self.log(f"  Attachments: {ok} copied, {missing} missing, "
                         f"{attachment_count - ok - missing} skipped.")

        self.state.last_record_count = total_records
        self.state.last_attachment_count = attachment_count

    # ------------------------------------------------------------------
    # Step 3
    # ------------------------------------------------------------------
    def _on_save_commentary(self):
        if not self.state.step2_done or not self.state.db_path:
            messagebox.showinfo("Step 2 required", "Build the database in step 2 first.")
            return
        comment = self.commentary_text.get("1.0", END).strip()
        if not comment:
            if not messagebox.askyesno("Empty commentary", "No commentary entered. Continue anyway?"):
                return
        author = self.author_var.get().strip() or None
        try:
            db = TransitDB(self.state.db_path)
            db.open_existing()
            db.write_commentary(comment, author=author)
            db.close()
            self.state.step3_done = True
            self.log("Commentary saved to transit.sqlite3.")
            self._set_tabs_enabled(step1=True, step2=True, step3=True, step4=True)
            default_name = default_zip_name(self.scope.name)
            self.zip_path_var.set(os.path.join(self.state.output_dir, default_name))
            self.nb.select(self.tab4)
        except Exception as exc:
            self.log(f"Saving commentary FAILED: {exc}")
            messagebox.showerror("Save failed", str(exc))

    # ------------------------------------------------------------------
    # Step 4
    # ------------------------------------------------------------------
    def _on_browse_zip_path(self):
        initial = self.zip_path_var.get() or (
            os.path.join(self.state.output_dir or ".", default_zip_name(self.scope.name if self.scope else "scope"))
        )
        path = filedialog.asksaveasfilename(
            title="Save ZIP as",
            defaultextension=".zip",
            initialfile=os.path.basename(initial),
            initialdir=os.path.dirname(initial) or ".",
            filetypes=[("ZIP files", "*.zip")],
        )
        if path:
            self.zip_path_var.set(path)

    def _on_build_zip(self):
        if not self.state.step3_done or not self.state.db_path:
            messagebox.showinfo("Step 3 required", "Save commentary in step 3 first.")
            return
        zip_path = self.zip_path_var.get().strip()
        if not zip_path:
            messagebox.showinfo("ZIP path required", "Choose where to save the ZIP file.")
            return
        try:
            self.log(f"Building ZIP at {zip_path} ...")
            out = build_zip(
                db_path=self.state.db_path,
                attachments_dir=self.state.attachments_dir,
                output_zip_path=zip_path,
                extra_manifest={
                    "scope_name": self.scope.name,
                    "scope_type": self.scope.type,
                    "record_count": self.state.last_record_count,
                    "attachment_count": self.state.last_attachment_count,
                },
            )
            self.state.step4_done = True
            self.step4_summary_var.set(f"ZIP created: {out}")
            self.log(f"Step 4 complete. ZIP at {out}")
            messagebox.showinfo("Done", f"Package created:\n{out}\n\n"
                                         "You can now hand this off to your other pipelines.")
        except Exception as exc:
            self.log(f"Step 4 FAILED: {exc}")
            messagebox.showerror("ZIP failed", str(exc))


def run(config_path: Optional[str] = None, default_author: Optional[str] = None):
    root = Tk()
    App(root, config_path=config_path, default_author=default_author)
    root.mainloop()

"""
dotProject (MySQL/MariaDB) client.

Since every dotProject install referenced here is a self-hosted fork with
custom changes, this module makes no assumption about table/column names:
the user supplies arbitrary SELECT queries in the scope config. Each named
query's result set becomes one table in the transit SQLite DB.

Attachments: dotProject (and most forks) store uploaded files on disk with
only metadata (and a filename/path) in the database. This module runs a
user-supplied "attachments" query and copies the referenced files from a
configured base path into the extraction's output folder.
"""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import pymysql
import pymysql.cursors

from .config import DotProjectScopeConfig


class DotProjectError(Exception):
    pass


@dataclass
class QueryResult:
    name: str
    columns: List[str]
    rows: List[Dict[str, Any]] = field(default_factory=list)
    sql_used: str = ""


class DotProjectSource:
    def __init__(self, cfg: DotProjectScopeConfig, timeout: int = 30):
        self.cfg = cfg
        self.timeout = timeout
        self._conn: Optional[pymysql.connections.Connection] = None

    # ------------------------------------------------------------------
    def connect(self) -> None:
        try:
            self._conn = pymysql.connect(
                host=self.cfg.host,
                port=self.cfg.port,
                user=self.cfg.user,
                password=self.cfg.password,
                database=self.cfg.database,
                charset=self.cfg.charset,
                connect_timeout=self.timeout,
                cursorclass=pymysql.cursors.DictCursor,
            )
        except pymysql.MySQLError as exc:
            raise DotProjectError(f"Could not connect to dotProject DB: {exc}") from exc

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> "DotProjectSource":
        self.connect()
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ------------------------------------------------------------------
    def test_connection(self) -> str:
        self.connect()
        with self._conn.cursor() as cur:
            cur.execute("SELECT VERSION() AS v")
            row = cur.fetchone()
        return f"Connected to {self.cfg.database} (server version {row['v']})"

    # ------------------------------------------------------------------
    def run_named_queries(
        self,
        queries_override: Optional[Dict[str, str]] = None,
    ) -> List[QueryResult]:
        if self._conn is None:
            self.connect()

        queries = queries_override if queries_override is not None else self.cfg.queries
        results: List[QueryResult] = []

        for name, sql in queries.items():
            with self._conn.cursor() as cur:
                try:
                    cur.execute(sql)
                except pymysql.MySQLError as exc:
                    raise DotProjectError(f"Query '{name}' failed: {exc}") from exc
                rows = cur.fetchall()
                columns = [d[0] for d in cur.description] if cur.description else []
            results.append(QueryResult(name=name, columns=columns, rows=rows, sql_used=sql))

        return results

    # ------------------------------------------------------------------
    def fetch_attachments(self, dest_dir: str) -> List[Dict[str, Any]]:
        """
        Runs the configured attachments query, then copies each referenced
        file from attachments.base_path (+ optional per-row subfolder) into
        dest_dir. Returns attachment records for the transit DB, including
        a 'copy_status' field ('ok' | 'missing' | 'skipped').
        """
        att_cfg = self.cfg.attachments
        if not att_cfg or not att_cfg.enabled:
            return []

        if self._conn is None:
            self.connect()

        with self._conn.cursor() as cur:
            try:
                cur.execute(att_cfg.query)
            except pymysql.MySQLError as exc:
                raise DotProjectError(f"Attachments query failed: {exc}") from exc
            rows = cur.fetchall()

        os.makedirs(dest_dir, exist_ok=True)
        records: List[Dict[str, Any]] = []

        for row in rows:
            filename = row.get(att_cfg.file_path_column)
            record = dict(row)
            record["source_base_path"] = att_cfg.base_path

            if not filename:
                record["copy_status"] = "skipped"
                record["local_path"] = None
                records.append(record)
                continue

            subfolder = row.get(att_cfg.folder_column) if att_cfg.folder_column else None
            src_parts = [att_cfg.base_path]
            if subfolder:
                src_parts.append(str(subfolder))
            src_parts.append(str(filename))
            src_path = os.path.join(*src_parts)

            dst_path = os.path.join(dest_dir, str(filename))
            # avoid collisions if two rows share a filename
            if os.path.exists(dst_path):
                base, ext = os.path.splitext(dst_path)
                suffix = 1
                while os.path.exists(f"{base}_{suffix}{ext}"):
                    suffix += 1
                dst_path = f"{base}_{suffix}{ext}"

            if os.path.isfile(src_path):
                shutil.copy2(src_path, dst_path)
                record["copy_status"] = "ok"
                record["local_path"] = dst_path
            else:
                record["copy_status"] = "missing"
                record["local_path"] = None
                record["source_path_tried"] = src_path

            records.append(record)

        return records

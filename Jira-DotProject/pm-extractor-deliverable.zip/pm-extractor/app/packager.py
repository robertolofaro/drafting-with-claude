"""
Step 4: package transit.sqlite3 + downloaded attachments into one ZIP.
"""
from __future__ import annotations

import json
import os
import zipfile
from datetime import datetime, timezone
from typing import Optional


def _now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def default_zip_name(scope_name: str) -> str:
    safe = "".join(c if (c.isalnum() or c in "-_") else "_" for c in scope_name.strip())
    return f"{safe}_{_now_stamp()}.zip"


def build_zip(
    db_path: str,
    attachments_dir: Optional[str],
    output_zip_path: str,
    extra_manifest: Optional[dict] = None,
) -> str:
    """
    Creates output_zip_path containing:
      transit.sqlite3           (the database as built in steps 2-3)
      attachments/...           (everything downloaded in step 2, if any)
      manifest.json             (basic metadata about the package)

    Returns output_zip_path.
    """
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"transit DB not found: {db_path}")

    manifest = {
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "db_filename": os.path.basename(db_path),
        "has_attachments": bool(attachments_dir and os.path.isdir(attachments_dir)),
    }
    if extra_manifest:
        manifest.update(extra_manifest)

    os.makedirs(os.path.dirname(os.path.abspath(output_zip_path)) or ".", exist_ok=True)

    with zipfile.ZipFile(output_zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(db_path, arcname=os.path.basename(db_path))

        if attachments_dir and os.path.isdir(attachments_dir):
            for root, _dirs, files in os.walk(attachments_dir):
                for fname in files:
                    full = os.path.join(root, fname)
                    rel = os.path.relpath(full, start=os.path.dirname(attachments_dir))
                    zf.write(full, arcname=rel)

        zf.writestr("manifest.json", json.dumps(manifest, indent=2))

    return output_zip_path

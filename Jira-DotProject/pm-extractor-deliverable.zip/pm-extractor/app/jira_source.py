"""
Minimal Jira REST client: paginated JQL search + attachment download.

Supports:
  - Jira Cloud (REST API v3, email + API token, HTTP Basic)
  - Jira Server / Data Center (REST API v2, username+password OR a
    Personal Access Token as a Bearer token)

No write operations are performed - this tool only reads.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import requests

from .config import JiraScopeConfig


class JiraError(Exception):
    pass


@dataclass
class JiraFetchResult:
    issues: List[Dict[str, Any]] = field(default_factory=list)
    jql_used: str = ""
    fields_used: List[str] = field(default_factory=list)
    total_available: int = 0


class JiraSource:
    def __init__(self, cfg: JiraScopeConfig, timeout: int = 30):
        self.cfg = cfg
        self.timeout = timeout
        self.session = requests.Session()
        self._configure_auth()
        self.api_version = "3" if cfg.deployment == "cloud" else "2"

    # ------------------------------------------------------------------
    def _configure_auth(self) -> None:
        auth = self.cfg.auth
        if self.cfg.deployment == "cloud":
            email = auth.get("email")
            token = auth.get("api_token")
            if not email or not token:
                raise JiraError("Jira Cloud requires auth.email and auth.api_token")
            self.session.auth = (email, token)
        else:
            pat = auth.get("personal_access_token")
            if pat:
                self.session.headers["Authorization"] = f"Bearer {pat}"
            else:
                username = auth.get("username")
                password = auth.get("password")
                if not username or not password:
                    raise JiraError(
                        "Jira Server/DC requires auth.personal_access_token, "
                        "or auth.username + auth.password"
                    )
                self.session.auth = (username, password)
        self.session.headers["Accept"] = "application/json"

    # ------------------------------------------------------------------
    def test_connection(self) -> str:
        """Returns a short human-readable identity string on success."""
        url = f"{self.cfg.base_url}/rest/api/{self.api_version}/myself"
        resp = self.session.get(url, timeout=self.timeout)
        if resp.status_code == 401:
            raise JiraError("Authentication failed (401). Check credentials in config.")
        resp.raise_for_status()
        data = resp.json()
        return data.get("displayName") or data.get("name") or data.get("accountId", "connected")

    # ------------------------------------------------------------------
    def fetch_issues(
        self,
        jql_override: Optional[str] = None,
        fields_override: Optional[List[str]] = None,
        progress_cb: Optional[Callable[[int, int], None]] = None,
    ) -> JiraFetchResult:
        jql = jql_override if jql_override is not None else self.cfg.jql
        fields = fields_override if fields_override is not None else (self.cfg.fields or None)

        url = f"{self.cfg.base_url}/rest/api/{self.api_version}/search"
        page_size = self.cfg.max_results_per_page
        start_at = 0
        total = None
        issues: List[Dict[str, Any]] = []

        while True:
            payload = {
                "jql": jql,
                "startAt": start_at,
                "maxResults": page_size,
            }
            if fields:
                payload["fields"] = fields

            resp = self.session.post(url, json=payload, timeout=self.timeout)
            if resp.status_code == 400:
                raise JiraError(f"Jira rejected the JQL/query (400): {resp.text[:500]}")
            if resp.status_code == 401:
                raise JiraError("Authentication failed (401). Check credentials in config.")
            resp.raise_for_status()
            data = resp.json()

            total = data.get("total", 0)
            page_issues = data.get("issues", [])
            issues.extend(page_issues)

            if progress_cb:
                progress_cb(len(issues), total)

            start_at += len(page_issues)
            if not page_issues or start_at >= total:
                break

        return JiraFetchResult(
            issues=issues,
            jql_used=jql,
            fields_used=fields or [],
            total_available=total or len(issues),
        )

    # ------------------------------------------------------------------
    def download_attachments(
        self,
        issues: List[Dict[str, Any]],
        dest_dir: str,
        progress_cb: Optional[Callable[[int, int], None]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Downloads every attachment found on the given issues into
        dest_dir/<issue_key>/<filename>. Returns a list of attachment
        records (issue_key, filename, local_path, size, mime_type, author,
        created) suitable for inserting into the transit DB.
        """
        records: List[Dict[str, Any]] = []

        pending = []
        for issue in issues:
            key = issue.get("key", "UNKNOWN")
            atts = (issue.get("fields") or {}).get("attachment") or []
            for att in atts:
                pending.append((key, att))

        total = len(pending)
        done = 0
        for key, att in pending:
            content_url = att.get("content")
            filename = att.get("filename", f"attachment_{att.get('id', 'unknown')}")
            issue_dir = os.path.join(dest_dir, key)
            os.makedirs(issue_dir, exist_ok=True)
            local_path = os.path.join(issue_dir, filename)

            if content_url:
                resp = self.session.get(content_url, timeout=self.timeout, stream=True)
                resp.raise_for_status()
                with open(local_path, "wb") as fh:
                    for chunk in resp.iter_content(chunk_size=65536):
                        if chunk:
                            fh.write(chunk)

            records.append({
                "issue_key": key,
                "attachment_id": att.get("id"),
                "filename": filename,
                "local_path": local_path,
                "size": att.get("size"),
                "mime_type": att.get("mimeType"),
                "author": (att.get("author") or {}).get("displayName"),
                "created": att.get("created"),
            })

            done += 1
            if progress_cb:
                progress_cb(done, total)

        return records

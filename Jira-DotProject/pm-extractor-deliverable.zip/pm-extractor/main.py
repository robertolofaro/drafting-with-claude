#!/usr/bin/env python3
"""
Entry point for the PM Extractor GUI.

Usage:
    python main.py [path/to/scopes.yaml] [--author "Name <email>"]

If no config path is given, you can load one from within the GUI
("Load config file..." button).
"""
from __future__ import annotations

import argparse
import sys

from app.gui import run


def main() -> int:
    parser = argparse.ArgumentParser(description="PM Extractor - Jira / dotProject -> transit.sqlite3")
    parser.add_argument("config", nargs="?", default=None, help="Path to scopes.yaml")
    parser.add_argument("--author", default=None, help="Default author name to prefill in step 3")
    args = parser.parse_args()

    run(config_path=args.config, default_author=args.author)
    return 0


if __name__ == "__main__":
    sys.exit(main())
